import discord
from discord.ext import commands, tasks
from discord import app_commands, utils as Utils
import asyncio
import requests
import datetime
import pytz
from colorama import Fore
import random
import sqlite3
from dotenv import load_dotenv
import os
from datetime import timedelta
from humanfriendly import parse_timespan, InvalidTimespan, format_timespan
import time
import json
from typing import List
from collections import deque
import sys
from googletrans import Translator
import typing
import aiohttp
import re
import io
from PIL import Image, ImageFont, ImageDraw
from io import BytesIO
import httpx
import dateutil.parser
import fortnite_api
from fortnite_api import StatsImageType, TimeWindow, AccountType
import validators
import qrcode
from pyfiglet import Figlet
import http.client
import threading
import instaloader
import openai

api_fn = fortnite_api.FortniteAPI(api_key="00152b49-c7e0-4a7d-913c-29a122d36ced")
insta = instaloader.Instaloader()

load_dotenv()
print("Caricando le variabili...")

Token = os.getenv('TOKEN')
client_id = os.getenv('CLIENT_ID')
client_secret = os.getenv('CLIENT_SECRET')
public_key = os.getenv('PUBLIC_KEY')
redirect_uri = os.getenv('REDIRECT_URI')
oauth_url = os.getenv('OAUTH_URL')
guild_id = os.getenv('GUILD_ID')
invite_url_tbs = os.getenv('INVITE_URL_TBS')
invite_url_bot_tbs = os.getenv('INVITE_URL_BOT_TBS')
link_status_tbs_bot = "https://tbsbot.statuspage.io"

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

openai.api_key = OPENAI_API_KEY
openai.Model.list()

print("Tutte le variabili sono state caricate procedo...")

API_ENDPOINT = 'https://canary.discord.com/api/v9'

intents = discord.Intents.all()
intents.presences = False

# Funzione per caricare gli id autorizzati dal file JSON
def load_authorized_ids():
    try:
        with open('authorized_id.json', 'r') as file:
            data = json.load(file)
        return data.get('authorized_ids', [])
    except (FileNotFoundError, json.JSONDecodeError):
        return []

# Funzione per salvare gli id autorizzati nel file JSON
def save_authorized_ids(authorized_ids):
    data = {'authorized_ids': authorized_ids}
    with open('authorized_id.json', 'w') as file:
        json.dump(data, file)

client = commands.Bot(command_prefix="$", description="A multi-functions discord bot", intents=intents)

reset_db = False

@tasks.loop(seconds=1)
async def reset_database_giveaways():
    global reset_db

    current_time = datetime.datetime.now(pytz.timezone('Europe/Rome'))

    if current_time.hour == 23 and current_time.minute == 59 and not reset_db:
        # Connessione al database
        conn = sqlite3.connect('giveaways.db')
        cursor = conn.cursor()

        # Elimina tutti i dati dalla tabella (sostituisci 'your_table_name' con il nome reale della tua tabella)
        cursor.execute('DELETE FROM giveaways')

        # Fai commit per effettuare le modifiche
        conn.commit()

        # Chiudi la connessione
        conn.close()

        reset_db = True

    # Verifica se è mezzanotte (00:00) e reimposta la variabile
    if current_time.hour == 23 and current_time.minute == 59 and reset_db:
        reset_db = False
        print(Fore.GREEN + "Il database è stato eliminato con successo e la variabile è stata impostata su False" + Fore.RESET)

# Connessione al database
conn = sqlite3.connect("player_bad.db")
db_cursor = conn.cursor()
db_cursor.execute('''
    CREATE TABLE IF NOT EXISTS bad_players (
        user_id INTEGER PRIMARY KEY,
        reason TEXT,
        severity INTEGER
    )
''')
conn.commit()

# Creazione del database e della tabella se non esistono
conn = sqlite3.connect('user_data.db')
cursor = conn.cursor()
cursor.execute('''
    CREATE TABLE IF NOT EXISTS user_activity (
        user_id INTEGER PRIMARY KEY,
        start_time TEXT,
        activity_time INTEGER
    )
''')
conn.commit()

translator = Translator()

# Tenta di caricare il valore di number_nitro_gen dal file JSON
try:
    with open("number_nitro_gen.json", "r") as file:
        number_nitro_gen = json.load(file)
except (FileNotFoundError, json.JSONDecodeError):
    # Se il file non esiste o contiene dati non validi, inizializza number_nitro_gen a 1
    number_nitro_gen = 1

print(number_nitro_gen)

class InviteButtons(discord.ui.View):
    def __init__(self, inv: str):
        super().__init__()
        self.inv = inv
        self.add_item(discord.ui.Button(label="Invite link", emoji="<:Invite:1178413450611925042>", url=self.inv))

    @discord.ui.button(label="Invite", style=discord.ButtonStyle.blurple)
    async def inviteserver(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(self.inv, ephemeral=True)

class ChannelsTicketLink(discord.ui.View):
    def __init__(self, server_id: str, channel_id: str):
        super().__init__()
        self.server_id = server_id
        self.channel_id = channel_id
        self.add_item(discord.ui.Button(label="Your Ticket", url=f"https://discord.com/channels/{self.server_id}/{self.channel_id}", emoji="<:Link:1178413223381311488>"))

class AvatarViewLink(discord.ui.View):
    def __init__(self, avatar_link: str):
        super().__init__()
        self.avatar_link = avatar_link
        self.add_item(discord.ui.Button(label="Avatar Url", url=self.avatar_link, emoji="<:Link:1178413223381311488>"))
        
guild_id_tbs = int(guild_id)

suggestion_channel = "1167402177598341180"

suggestion_channel_id = int(suggestion_channel)

allowed_guild_id = 1158829802690727988  # Sostituisci con l'ID della tua gilda

def in_allowed_guild(interaction):
    return interaction.guild.id == allowed_guild_id

class TbsStaff(app_commands.Group):
    ...
tbsstaff = TbsStaff(name="staff", description="Moderation")

class TbsGiveaway(app_commands.Group):
    ...
tbsgiveaway = TbsGiveaway(name="giveaway", description="Giveaway")

class TbsRole(app_commands.Group):
    ...
tbsrole = TbsRole(name="role", description="Role moderation")

class TbsRall(app_commands.Group):
    ...
tbsrall = TbsRall(name="rall", description="Role remove moderation")

class EmojiTbs(app_commands.Group):
    ...
emojitbs = EmojiTbs(name="emoji", description="Emoji context")

class FortniteTbs(app_commands.Group):
    ...
fortnitetbs = FortniteTbs(name="fortnite", description="Fortnite commands")

class TicketTbs(app_commands.Group):
    ...
tickettbs = TicketTbs(name="ticket", description="Ticket commands")

class WelcomeTbs(app_commands.Group):
    ...
welcometbs = WelcomeTbs(name="welcome", description="Welcome Commands")

class AnnuncioModal(discord.ui.Modal, title="Crea un annuncio"):
    ac_title = discord.ui.TextInput(
        style=discord.TextStyle.short,
        label="Title",
        required=False,
        placeholder="Inserisci il titolo dell'annuncio"
    )

    ac_message = discord.ui.TextInput(
        style=discord.TextStyle.long,
        label="Message",
        required=True,
        max_length=500,
        min_length=2,
        placeholder="Inserisci l'annuncio"
    )

    async def on_submit(self, interaction: discord.Interaction):
        channel = interaction.channel
        await channel.send(self.ac_message.value)
        await interaction.response.send_message("Annuncio inviato", ephemeral=True)


    async def on_error(self, interaction: discord.Interaction, error):
        ...

class SuggestionModal(discord.ui.Modal, title="Make a suggestion"):
    ac_title = discord.ui.TextInput(
        style=discord.TextStyle.short,
        label="Title Suggestion",
        required=True,
        max_length=100,
        min_length=1,
        placeholder="Inserisci qui il titolo della tua suggestion"
    )

    ac_message = discord.ui.TextInput(
        style=discord.TextStyle.long,
        label="Suggestion",
        required=True,
        max_length=500,
        min_length=5,
        placeholder="Inserisci la tua suggestion"
    )

    async def on_submit(self, interaction: discord.Interaction):

        channel = interaction.guild.get_channel(channel_id=suggestion_channel_id)
        embed = discord.Embed(title="New Suggestion", color=discord.Color.yellow())
        embed.add_field(name=self.ac_title.value, value=self.ac_message.value, inline=False)
        embed.add_field(name="Suggestion by", value=self.user.mention)
        embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embed.set_thumbnail(url=self.user.avatar._url)

        await channel.send(embed=embed)
        await interaction.response.send_message("Suggestion inviata, grazie per il supporto!", ephemeral=True)


    async def on_error(self, interaction: discord.Interaction, error):
        ...

class EmbedCreateModal(discord.ui.Modal, title="Make a embed"):
    embed_title = discord.ui.TextInput(
        style=discord.TextStyle.short,
        label="Embed Title",
        required=True,
        max_length=100,
        min_length=1,
        placeholder="Inserisci qui il titolo dell\'embed"
    )

    embed_description = discord.ui.TextInput(
        style=discord.TextStyle.short,
        label="Embed Description",
        required=False,
        max_length=200,
        min_length=5,
        placeholder="Inserisci la descrizione dell'embed"
    )
    
    embed_field_name = discord.ui.TextInput(
        style=discord.TextStyle.short,
        label="Embed Field 1 Name",
        required=False,
        max_length=100,
        min_length=1,
        placeholder="Inserisci il nome del field"
    )
    
    embed_field_value = discord.ui.TextInput(
        style=discord.TextStyle.short,
        label="Embed Field 1 Value",
        required=False,
        max_length=200,
        min_length=5,
        placeholder="Inserisci il valore del field"
    )

    embed_thumbnail = discord.ui.TextInput(
        style=discord.TextStyle.short,
        label="Thumbnail",
        required=False,
        max_length=200,
        min_length=5,
        placeholder="Inserisci l'url del tuhmbnail"
    )

    async def on_submit(self, interaction: discord.Interaction):
        channel = interaction.channel
        embed = discord.Embed(title=self.embed_title.value, color=discord.Color.yellow())

        # Aggiungi la descrizione solo se è stata inserita dall'utente
        if self.embed_description.value:
            embed.description = self.embed_description.value

        # Aggiungi i campi solo se sono stati inseriti dall'utente
        if self.embed_field_name.value and self.embed_field_value.value:
            embed.add_field(name=self.embed_field_name.value, value=self.embed_field_value.value, inline=False)
        
        if self.embed_thumbnail:
            embed.set_thumbnail(url=self.embed_thumbnail.value)

        embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")

        await channel.send(embed=embed)
        await interaction.response.send_message("Embed creato e inviato", ephemeral=True)

    async def on_error(self, interaction: discord.Interaction, error):
        ...

class ButtonVerify(discord.ui.View):
    def __init__(self) -> None:
        super().__init__(timeout=None)
    
    @discord.ui.button(label="Verify", emoji="<:captcha:1167830817347743846>", style=discord.ButtonStyle.green, custom_id="verify_button")
    async def verify_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        verify_role_name = "Verified"  # Sostituisci con il nome del ruolo che vuoi cercare
        not_verify_role_name = "Unverified"

        verify_role = discord.utils.get(interaction.guild.roles, name=verify_role_name)
        not_verify_role = discord.utils.get(interaction.guild.roles, name=not_verify_role_name)
        
        if verify_role is not None:
            if not_verify_role is not None:
                if not_verify_role in interaction.user.roles:
                    await interaction.user.remove_roles(not_verify_role)
                    await interaction.user.add_roles(verify_role)
                    embedverifysuccess = discord.Embed(title="Verification Success 🎉", description="You have successfully verified your account and gained access to the server 😈", color=discord.Color.yellow())
                    embedverifysuccess.set_footer(icon_url=ICONTBS, text="Powered by TBS")
                    embedverifysuccess.set_image(url="https://cdn.discordapp.com/attachments/1167209178515902515/1167830290178248824/VOE-Image-1.jpg?ex=654f8db6&is=653d18b6&hm=90659a5c6f1956e5b91dd69294acd5494852c236a1dbb3bf59ce1f509755df02&")
                    await interaction.response.send_message(embed=embedverifysuccess, ephemeral=True)
                else:
                    await interaction.response.send_message(f"You already have verified your account in this server!", ephemeral=True)
            else:
                await interaction.response.send_message(f"The verification role was not found. Please contact the server administrator.", ephemeral=True)
        else:
            await interaction.response.send_message(f"The verification role was not found. Please contact the server administrator.", ephemeral=True)

class ButtonVerifySetup(discord.ui.View):
    def __init__(self) -> None:
        super().__init__(timeout=None)
    
    @discord.ui.button(label="Ok", style=discord.ButtonStyle.green, custom_id="ok_button")
    async def verify_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.clear_items()
        await interaction.response.edit_message(view=self)
        server = interaction.guild
        # Ottieni l'immagine del server
        server_icon_url = str(server.icon.url) if server.icon else "Nessuna immagine del server disponibile"
        embedverify = discord.Embed(title="Verification <:Verify:1167831092754137112>", description="To verify your account and gain access to the server click the (verify) button 👻", color=discord.Color.yellow())
        embedverify.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embedverify.set_image(url="https://cdn.discordapp.com/attachments/1167209178515902515/1167830289842708572/verification.jpg?ex=654f8db6&is=653d18b6&hm=4cb84709275a8cc7e125a818e1f3140cdba21e2f66e475b4a72fb8ec58d76bcd&")
        if server_icon_url:
            embedverify.set_thumbnail(url=server_icon_url)
        else:
            embedverify.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
        await interaction.followup.send(embed=embedverify, view=ButtonVerify())

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.red, custom_id="cancel_button")
    async def cancel_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.clear_items()
        await interaction.response.edit_message(view=self)
        await interaction.followup.send(content="Action annulled", ephemeral=True)

    @discord.ui.button(label="Auto-create", style=discord.ButtonStyle.blurple, custom_id="auto_create_button")
    async def auto_create_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.children[2].disabled = True
        await interaction.response.edit_message(view=self)
        
        guild = interaction.guild
        
        # Controlla se esistono già ruoli con gli stessi nomi nel server
        unverified_role = discord.utils.get(guild.roles, name="Unverified")
        verified_role = discord.utils.get(guild.roles, name="Verified")
        
        # Se i ruoli non esistono, creali
        if unverified_role is None:
            unverified_role = await guild.create_role(name="Unverified", reason="Creazione del ruolo Unverified")
        if verified_role is None:
            verified_role = await guild.create_role(name="Verified", reason="Creazione del ruolo Verified")
        
        await interaction.followup.send(content=f"Ruoli: {unverified_role.mention} e {verified_role.mention} creati con successo, riesegui il comando e clicca OK!", ephemeral=True)

class GiveawayView(discord.ui.View):
    def __init__(self, giveaway_id, server_id):
        super().__init__(timeout=None)
        self.giveaway_id = giveaway_id
        self.server_id = server_id

    @discord.ui.button(label="Join Giveaway", emoji="🎉", style=discord.ButtonStyle.blurple, custom_id="join_giveaway")
    async def join_giveaway(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Connessione al database (assumendo SQLite come esempio)
        conn = sqlite3.connect("giveaways.db")
        c = conn.cursor()

        try:
            # Ottieni i dati dei partecipanti dal database
            c.execute("SELECT participants FROM giveaways WHERE server_id = ? AND giveaway_id = ?", (self.server_id, self.giveaway_id))
            participants_data = c.fetchone()

            if participants_data and participants_data[0]:
                participants = json.loads(participants_data[0])  # Converti i partecipanti in una lista
            else:
                participants = []

            user_id = str(interaction.user.id)
            if user_id in participants:
                # Se l'utente è già tra i partecipanti, invia un messaggio di errore
                await interaction.response.send_message(content="Hai già partecipato a questo giveaway!", ephemeral=True)
            else:
                # Se l'utente non è tra i partecipanti, aggiungi il suo ID alla lista e aggiorna il database
                participants.append(user_id)
                updated_participants = json.dumps(participants)  # Converti la lista dei partecipanti in una stringa JSON
                if participants_data:
                    # Se ci sono già partecipanti, aggiorna la lista nel database
                    c.execute("UPDATE giveaways SET participants = ? WHERE server_id = ? AND giveaway_id = ?",
                            (updated_participants, self.server_id, self.giveaway_id))
                else:
                    # Se non ci sono ancora partecipanti, crea un nuovo record nel database
                    c.execute("INSERT INTO giveaways (server_id, giveaway_id, participants) VALUES (?, ?, ?)",
                            (self.server_id, self.giveaway_id, updated_participants))
                conn.commit()

                # Invia un messaggio di conferma
                await interaction.response.send_message(content="Hai partecipato con successo al giveaway!", ephemeral=True)

        except Exception as e:
            # Se si verifica un errore, invia un messaggio di errore
            await interaction.response.send_message(content=f"Errore durante la partecipazione al giveaway: {e}", ephemeral=True)

        finally:
            # Chiudi la connessione al database
            conn.close()

class PaginatorView(discord.ui.View):
    def __init__(self, embeds: List[discord.Embed]) -> None:
        super().__init__(timeout=30)

        self._embeds = embeds
        self._queue = deque(embeds)
        self._initial = embeds[0]
        self._len = len(embeds)
        self._current_page = 1
        self.children[0].disabled = True
        self._queue[0].set_footer(text=f"Pages of {self._current_page}/{self._len}")

    async def update_buttons(self, interaction: discord.Interaction) -> None:
        for i in self._queue:
            i.set_footer(text=f"Pages of {self._current_page}/{self._len}")
        if self._current_page == self._len:
            self.children[1].disabled = True
        else:
            self.children[1].disabled = False
        if self._current_page == 1:
            self.children[0].disabled = True
        else:
            self.children[0].disabled = False

        await interaction.message.edit(view=self)

    @discord.ui.button(emoji="⏮️")
    async def previous(self, interaction: discord.Interaction, _):
        self._queue.rotate(-1)
        embed = self._queue[0]
        self._current_page -= 1
        await self.update_buttons(interaction)
        await interaction.response.edit_message(embed=embed)

    @discord.ui.button(emoji="⏭️")
    async def next(self, interaction: discord.Interaction, _):
        self._queue.rotate(1)
        embed = self._queue[0]
        self._current_page += 1
        await self.update_buttons(interaction)
        await interaction.response.edit_message(embed=embed)

    @property
    def initial(self) -> discord.Embed:
        return self._initial

class HelpCommandView(discord.ui.View):
    def __init__(self) -> None:
        super().__init__(timeout=None)
        self.add_item(discord.ui.Button(label="TBS", emoji="<a:tbsemoji:1178356240598962176>", url=invite_url_tbs))
        self.add_item(discord.ui.Button(label="TBS BOT", emoji="<:Bot:1178414876104867912>", url=invite_url_bot_tbs))
        self.add_item(discord.ui.Button(label="TBS STATUS", emoji="<:server:1177579255236935700>", url=link_status_tbs_bot))

class TicketButtonView(discord.ui.View):
    def __init__(self) -> None:
        super().__init__(timeout=None)

    @discord.ui.button(label="Create ticket", emoji="<a:Nitro_pass_a:1175081966689857536>", style=discord.ButtonStyle.blurple, custom_id="create_ticket")
    async def create_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Ottieni la categoria tramite ID
        category_name = "ticket"
        category = discord.utils.get(interaction.guild.categories, name=category_name)

        if category is None:
            category = await interaction.guild.create_category(category_name)

        if category:
            
            # Controlla se l'utente ha già un ticket aperto nella categoria
            existing_ticket = discord.utils.get(category.channels, type=discord.ChannelType.text, topic=f"Ticket open by {interaction.user.name}")
            if existing_ticket:
                await interaction.response.send_message(f"{interaction.user.mention}, you already have an open ticket! You can find it in {existing_ticket.mention}", ephemeral=True)
                return
            
            # Invia un messaggio di conferma all'utente
            await interaction.response.send_message(f"<a:766617203050938398:1178416688354578653> Checking permission...", ephemeral=True)
            # Crea un canale con il nome dell'utente
            user_name = interaction.user.name
            ticket_channel = await category.create_text_channel(name=f"ticket-{user_name}", topic=f"Ticket open by {interaction.user.name}")

            await interaction.edit_original_response(content="<a:766617203050938398:1178416688354578653> Creating ticket...")

            # Ottieni il ruolo "ticket support" tramite ID
            ticket_support_role_name = "ticket support"
            ticket_support_role = discord.utils.get(interaction.guild.roles, name=ticket_support_role_name)

            await interaction.edit_original_response(content="<a:766617203050938398:1178416688354578653> Set ticket permission...")

            # Imposta i permessi del canale
            await ticket_channel.set_permissions(interaction.guild.default_role, view_channel=False)  # everyone non può vedere il canale
            await ticket_channel.set_permissions(interaction.user, send_messages=True, read_message_history=True, view_channel=True)  # l'utente che ha premuto il bottone può inviare messaggi e vedere il canale
            await ticket_channel.set_permissions(ticket_support_role, send_messages=True, read_message_history=True, view_channel=True)  # il ruolo ticket support può fare tutto

            embedticketwelcome = discord.Embed(color=discord.Color.green())
            embedticketwelcome.add_field(name="", value="Support will be with you shortly.\nTo close this ticket react with 🔒\n\nIn the meantime, please describe your problem to us")
            embedticketwelcome.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            embedticketwelcome.set_thumbnail(url=ICONTBS)

            await ticket_channel.send(content=f"Hey {interaction.user.mention} welcome! | {ticket_support_role.mention}", embed=embedticketwelcome, view=CloseClaimTicketButton())

            embedticketcreate = discord.Embed(title="Ticket Create", description=f"You can find it in {ticket_channel.mention} ✅", color=discord.Color.yellow())
            embedticketcreate.set_author(name=f"{interaction.user.name}", icon_url=interaction.user.avatar.url)
            embedticketcreate.set_thumbnail(url=ICONTBS)
            embedticketcreate.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            # Invia un messaggio di conferma all'utente
            await interaction.edit_original_response(content="", embed=embedticketcreate, view=ChannelsTicketLink(server_id=interaction.guild.id, channel_id=ticket_channel.id))

class CloseClaimTicketButton(discord.ui.View):
    def __init__(self) -> None:
        super().__init__(timeout=None)

    @discord.ui.button(label="Close ticket", emoji="🔒", style=discord.ButtonStyle.red, custom_id="delete_ticket")
    async def delete_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Controlla se l'utente ha il ruolo "staff"
        staff_role_name = "staff"
        staff_role = discord.utils.get(interaction.guild.roles, name=staff_role_name)

        if staff_role not in interaction.user.roles:
            await interaction.response.send_message("Non hai il permesso di chiudere il ticket", ephemeral=True)
            return

        self.clear_items()
        await interaction.response.edit_message(view=self)

        # Invia un messaggio dicendo che il canale verrà eliminato tra 10 secondi
        await interaction.followup.send(f"Il ticket verrà chiuso tra 10 secondi. Salvate eventuali informazioni importanti")

        # Attendi 10 secondi
        await asyncio.sleep(10)

        # Elimina il canale
        await interaction.channel.delete()
    
    @discord.ui.button(label="Claim ticket", emoji="✅", style=discord.ButtonStyle.green, custom_id="claim_ticket")
    async def claim_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Logica per claimare il ticket
        claim_staff_role_name = "staff"
        claim_staff_role = discord.utils.get(interaction.guild.roles, name=claim_staff_role_name)
        if claim_staff_role in interaction.user.roles:
            self.children[1].disabled = True  # Disabilita il bottone "Claim ticket"
            self.children[1].label = f"Claimed by {interaction.user.name}"  # Modifica il testo del bottone "Claim ticket"
            self.children[2].disabled = False  # Abilita il bottone "Unclaim ticket"
            await interaction.response.edit_message(view=self)
            await interaction.followup.send(f"Ticket claimed by {interaction.user.mention}")
        else:
            await interaction.response.send_message("Non puoi claimare questo ticket", ephemeral=True)

    @discord.ui.button(label="Unclaim ticket", emoji="❌", style=discord.ButtonStyle.gray, custom_id="unclaim_ticket", disabled=True)
    async def unclaim_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Logica per unclaimare il ticket
        unclaim_staff_role_name = "staff"
        unclaim_staff_role = discord.utils.get(interaction.guild.roles, name=unclaim_staff_role_name)
        if unclaim_staff_role in interaction.user.roles:
            self.children[1].disabled = False  # Abilita il bottone "Claim ticket"
            self.children[1].label = "Claim ticket"  # Ripristina il testo del bottone "Claim ticket"
            self.children[2].disabled = True  # Disabilita il bottone "Unclaim ticket"
            await interaction.response.edit_message(view=self)
            await interaction.followup.send(f"Ticket unclaimed by {interaction.user.mention}")
        else:
            await interaction.response.send_message("Non puoi unclaimare questo ticket", ephemeral=True)

class TicketButtonSetup(discord.ui.View):
    def __init__(self) -> None:
        super().__init__(timeout=None)
    
    @discord.ui.button(label="Create", style=discord.ButtonStyle.green, custom_id="create_button")
    async def create_button(self, interaction: discord.Interaction, button: discord.ui.Button):

        guild = interaction.guild

        # Controlla se esistono già ruoli con gli stessi nomi nel server
        staff_role = discord.utils.get(guild.roles, name="staff")
        ticket_support_role = discord.utils.get(guild.roles, name="ticket support")
        category = discord.utils.get(interaction.guild.categories, name="ticket")

        if staff_role is None:
            await interaction.response.send_message("The staff role is missing, click the button auto crate", ephemeral=True)
            return
        
        if ticket_support_role is None:
            await interaction.response.send_message("The ticket support role is missing, click the button auto crate", ephemeral=True)
            return
        
        if category is None:
            await interaction.response.send_message("The category ticket is missing, click the button auto crate", ephemeral=True)
            return

        self.clear_items()
        await interaction.response.edit_message(view=self)

        server = interaction.guild
        # Ottieni l'immagine del server
        server_icon_url = str(server.icon.url) if server.icon else "Nessuna immagine del server disponibile"
        achennl = interaction.channel
        embedticket = discord.Embed(title="Ticket🎫", color=discord.Color.yellow())
        embedticket.add_field(name="", value="Create a ticket by clicking the button below!")
        embedticket.set_footer(icon_url=ICONTBS, text="Powered by TBS")

        if server_icon_url:
            embedticket.set_thumbnail(url=server_icon_url)
        else:
            embedticket.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)

        await interaction.channel.send(embed=embedticket, view=TicketButtonView())

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.red, custom_id="no_button")
    async def anull_button(self, interaction: discord.Interaction, button: discord.ui.Button):

        self.clear_items()
        await interaction.response.edit_message(view=self)

        await interaction.followup.send(content="Action annulled", ephemeral=True)

    @discord.ui.button(label="Auto-create", style=discord.ButtonStyle.blurple, custom_id="auto_create_ticket_button")
    async def auto_create_ticket_button(self, interaction: discord.Interaction, button: discord.ui.Button):

        self.children[2].disabled = True
        await interaction.response.edit_message(view=self)
        
        guild = interaction.guild
        
        # Controlla se esistono già ruoli con gli stessi nomi nel server
        staff_role = discord.utils.get(guild.roles, name="staff")
        ticket_support_role = discord.utils.get(guild.roles, name="ticket support")
        category = discord.utils.get(interaction.guild.categories, name="ticket")
        
        # Se i ruoli non esistono, creali
        if staff_role is None:
            staff_role = await guild.create_role(name="staff", reason="Creation role staff for ticket")
        if ticket_support_role is None:
            ticket_support_role = await guild.create_role(name="ticket support", reason="Creation role ticket support for ticket")
        if category is None:
            category = await interaction.guild.create_category("ticket", reason="Creation a category ticket for ticket open")

        await interaction.followup.send(content=f"Rules: {staff_role.mention} and {ticket_support_role.mention} success create, and the category {category.mention} success create, click Create button!", ephemeral=True)

class ModerationLogsView(discord.ui.View):
    def __init__(self) -> None:
        super().__init__(timeout=None)

    @discord.ui.button(label="Ban", emoji="<:Bannicon:1165713026452816073>", style=discord.ButtonStyle.gray, custom_id="ban_logs")
    async def ban_logs_user(self, interaction: discord.Interaction, button: discord.ui.Button):
        
        if interaction.user.guild_permissions.administrator or interaction.user.guild_permissions.ban_members:
            # Ottieni l'ID dell'utente dall'embed
            embed = interaction.message.embeds[0]  # Assumi che ci sia solo un embed
            user_id_field = next(field for field in embed.fields if field.name == "User ID 🆔")
            user_id_from_embed = int(user_id_field.value)

            # Banna l'utente con l'ID specificato
            user_to_ban = interaction.guild.get_member(user_id_from_embed)
            if user_to_ban:
                await user_to_ban.ban(reason="Banned from moderation logs")
                self.clear_items()
                await interaction.response.edit_message(view=self)
                await interaction.followup.send(f"User {user_to_ban.name} has been banned", ephemeral=True)
            else:
                await interaction.response.send_message(f"User {user_id_from_embed} not found.", ephemeral=True)

        else:
            embednoperm = discord.Embed(title="No perms <:Staff:1164636542103474296>", description="Non hai il permesso (administrator or ban_members) per eseguire questo comando", color=discord.Color.red())
            embednoperm.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            embednoperm.set_thumbnail(url=ICONTBS)
            embednoperm.set_footer(icon_url=ICONTBS, text="Powered by TBS")

            await interaction.response.send_message(embed=embednoperm, ephemeral=True)

    @discord.ui.button(label="Kick", emoji="🛠️", style=discord.ButtonStyle.gray, custom_id="kick_logs")
    async def kick_logs_user(self, interaction: discord.Interaction, button: discord.ui.Button):
        
        if interaction.user.guild_permissions.administrator or interaction.user.guild_permissions.ban_members or interaction.user.guild_permissions.kick_members:
            # Ottieni l'ID dell'utente dall'embed
            embed = interaction.message.embeds[0]  # Assumi che ci sia solo un embed
            user_id_field = next(field for field in embed.fields if field.name == "User ID 🆔")
            user_id_from_embed = int(user_id_field.value)

            # Banna l'utente con l'ID specificato
            user_to_ban = interaction.guild.get_member(user_id_from_embed)
            if user_to_ban:
                await user_to_ban.kick(reason="Banned from moderation logs")
                self.clear_items()
                await interaction.response.edit_message(view=self)
                await interaction.followup.send(f"User {user_to_ban.name} has been kickked", ephemeral=True)
            else:
                await interaction.response.send_message(f"User {user_id_from_embed} not found.", ephemeral=True)
                
        else:
            embednoperm = discord.Embed(title="No perms <:Staff:1164636542103474296>", description="Non hai il permesso (administrator or ban_members or kick_members) per eseguire questo comando", color=discord.Color.red())
            embednoperm.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            embednoperm.set_thumbnail(url=ICONTBS)

            await interaction.response.send_message(embed=embednoperm, ephemeral=True)

ICONTBS = "https://cdn.discordapp.com/icons/1158829802690727988/a_b0a97cd85b882aee7f3790f08e393a0f.gif"

giveaway_active = {}
giveaway_end = []

@client.event
async def on_ready():
    print(Fore.GREEN + "We have logged in as " + Fore.BLUE +  f"{client.user}")
    print(Fore.YELLOW + "------")

    update_bot_presence.start()
    reset_activity_data.start()
    reset_database_giveaways.start()
    print(Fore.GREEN + "Task entrate in funzione")
    print(Fore.YELLOW + "------")   

    client.tree.remove_command(tbsstaff)
    client.tree.remove_command(tbsgiveaway)
    client.tree.remove_command(tbsrole)
    client.tree.remove_command(tbsrall)
    client.tree.remove_command(emojitbs)
    client.tree.remove_command(fortnitetbs)
    client.tree.remove_command(tickettbs)
    client.tree.remove_command(welcometbs)
    print(Fore.GREEN + "Comandi " + Fore.RED + "(/)" + Fore.GREEN + " in caricamento")
    print(Fore.YELLOW + "------")

    client.tree.add_command(tbsstaff)
    client.tree.add_command(tbsgiveaway)
    client.tree.add_command(tbsrole)
    client.tree.add_command(tbsrall)
    client.tree.add_command(emojitbs)
    client.tree.add_command(fortnitetbs)
    client.tree.add_command(tickettbs)
    client.tree.add_command(welcometbs)
    client.add_view(ButtonVerify())
    client.add_view(TicketButtonView())
    client.add_view(CloseClaimTicketButton())
    client.add_view(TicketButtonSetup())
    client.add_view(ModerationLogsView())
    await client.tree.sync()
    print(Fore.GREEN + "Comandi " + Fore.RED + "(/)" + Fore.GREEN + " ricaricati e registrati")
    print(Fore.YELLOW + "------")

async def activity_autocomplete(interaction: discord.Interaction, current: str) -> typing.List[app_commands.Choice[str]]:
    data = []
    for activity_choice in ['Minecraft', 'Grand Theft Auto V', 'Grand Theft Auto', 'Spotify', 'Fortnite', 'Rocket League', 'Roblox']:
        if current.lower() in activity_choice.lower():
            data.append(app_commands.Choice(name=activity_choice, value=activity_choice))
    return data

async def nsfw_autocomplete(interaction: discord.Interaction, current: str) -> typing.List[app_commands.Choice[str]]:
    data = []
    for nsfw_choice in ['ass', 'pussy', 'boobs', 'hentai', 'thigh', 'blowjob']:
        if current.lower() in nsfw_choice.lower():
            data.append(app_commands.Choice(name=nsfw_choice, value=nsfw_choice))
    return data

async def addbad_autocomplete(interaction: discord.Interaction, current: str) -> typing.List[app_commands.Choice[str]]:
    data = []
    for addbad_choice in ['1', '2', '3']:
        if current.lower() in addbad_choice.lower():
            data.append(app_commands.Choice(name=addbad_choice, value=addbad_choice))
    return data

async def accounttype_autocomplete(interaction: discord.Interaction, current: str) -> typing.List[app_commands.Choice[str]]:
    data = []
    for accounttype_choice in ['epic', 'psn', 'xbl']:
        if current.lower() in accounttype_choice.lower():
            data.append(app_commands.Choice(name=accounttype_choice, value=accounttype_choice))
    return data

async def timewindows_autocomplete(interaction: discord.Interaction, current: str) -> typing.List[app_commands.Choice[str]]:
    data = []
    for timewindows_choice in ['lifetime', 'season']:
        if current.lower() in timewindows_choice.lower():
            data.append(app_commands.Choice(name=timewindows_choice, value=timewindows_choice))
    return data

@tasks.loop(seconds=10)
async def update_server_count():
    server_count = len(client.guilds)

    activity = discord.Activity(type=discord.ActivityType.watching, name=f"{server_count} servers")
    await client.change_presence(status=discord.Status.online, activity=activity)
    await asyncio.sleep(10)

@tasks.loop(seconds=10)
async def update_help_command():
    # Assicurati di utilizzare la variabile globale number_nitro_gen
    activity = discord.Activity(type=discord.ActivityType.playing, name=f"/help")
    await client.change_presence(status=discord.Status.dnd, activity=activity)
    await asyncio.sleep(10)

@tasks.loop(seconds=10)
async def update_status_command():
    # Assicurati di utilizzare la variabile globale number_nitro_gen
    activity = discord.Activity(type=discord.ActivityType.watching, name=f"/status")
    await client.change_presence(status=discord.Status.dnd, activity=activity)
    await asyncio.sleep(10)

@tasks.loop(seconds=10)
async def update_member_count():
    total_members = sum(len(guild.members) for guild in client.guilds)

    activity = discord.Activity(type=discord.ActivityType.watching, name=f"{total_members} total members")
    await client.change_presence(status=discord.Status.online, activity=activity)
    await asyncio.sleep(10)


@tasks.loop(seconds=5)
async def update_bot_presence():
    await update_server_count()
    await update_help_command()
    await update_status_command()
    await update_member_count()

@tasks.loop(hours=24)
async def reset_activity_data():
    # Resetta i dati di attività per tutti gli utenti
    cursor.execute('DELETE FROM user_activity')
    conn.commit()

@client.event
async def on_guild_join(guild: discord.Guild):

    # Ottieni gli audit logs del server per l'azione di invito del bot
    async for entry in guild.audit_logs(action=discord.AuditLogAction.bot_add, limit=1):
        inviter = entry.user

        # Crea un embed di benvenuto
        welcome_embed = discord.Embed(
            title=f"New server! `{guild.name}`<:join:1167890762453766288><:Among_Us_Red:1167890617926430783>",
            description=f"Thanks for inviting me to your amazing server! <:nitro_boost12:1166368431726133318><:Discord:1167891064280064010>\nTo get started, run the command `/help`, it will show you all the information you are interested in! <:nitro_boost24:1166368361987440722><:ActiveDev_Badge:1164635706778460190>\nHave a nice stay! <:nitro_boost6:1166368540828373065><:Verify:1167831092754137112>",
            color=discord.Color.green()
        )
        welcome_embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        welcome_embed.set_thumbnail(url=ICONTBS)

        # Invia l'embed nel primo canale testuale disponibile nel server
        for channel in guild.text_channels:
            if isinstance(channel, discord.TextChannel):
                permissions = channel.permissions_for(guild.me)
                if permissions.send_messages:
                    await channel.send(content=f"Hey {inviter.mention}", embed=welcome_embed, view=HelpCommandView())
                    break
    try:
        # Crea l'auto moderation rule nel server Discord
        rule1 = await guild.create_automod_rule(
            name="Block Mention",  # Puoi personalizzare il nome come preferisci
            event_type=discord.AutoModRuleEventType.message_send,
            trigger=discord.AutoModTrigger(mention_limit=10),
            actions=[discord.AutoModRuleAction(custom_message=None), discord.AutoModRuleAction(duration=timedelta(minutes=5))],
            enabled=True,
            reason="Bot join"
        )

        # Crea l'auto moderation rule nel server Discord
        rule2 = await guild.create_automod_rule(
            name="Block Suspected Spam Content",  # Puoi personalizzare il nome come preferisci
            event_type=discord.AutoModRuleEventType.message_send,
            trigger=discord.AutoModTrigger(type=discord.AutoModRuleTriggerType.spam),
            actions=[discord.AutoModRuleAction(custom_message=None)],
            enabled=True,
            reason="Bot join"
        )

        # Crea l'auto moderation rule nel server Discord
        rule3 = await guild.create_automod_rule(
            name="Block Custom Words",  # Puoi personalizzare il nome come preferisci
            event_type=discord.AutoModRuleEventType.message_send,
            trigger=discord.AutoModTrigger(keyword_filter=['Set here the words you want to block']),
            actions=[discord.AutoModRuleAction(custom_message=None)],
            enabled=True,
            reason="Bot join"
        )

    except:
        print(f"Error while creating automod rules in the new server {guild.name}")

    embed_join_prize = discord.Embed(title="Thankyou for invite me! <:Award_Icon:1163094204621262968><:role_bot:1166369625882230854><:join:1167890762453766288>", color=discord.Color.yellow())
    embed_join_prize.add_field(name="Info", value="use /bot help for more info", inline=False)
    embed_join_prize.set_footer(icon_url=ICONTBS, text="Powered by TBS")
    embed_join_prize.set_thumbnail(url=ICONTBS)

    if rule1:
        if rule2:
            if rule3:
                embed_join_prize.add_field(name="AutoMod", value="I have configurate your server with automod rules", inline=False)

            else:
                embed_join_prize.add_field(name="", value="Error while creating automod rule", inline=False)
        else:
            embed_join_prize.add_field(name="", value="Error while creating automod rule", inline=False)
    else:
        embed_join_prize.add_field(name="", value="Error while creating automod rule", inline=False)

    await inviter.send(embed=embed_join_prize)

@client.tree.command(name="seed-gen", description="Generate a random seed for your minecraft world")
async def seed_gen(interaction: discord.Interaction):
    alphabet = "0123456789"
    random_seed = ''.join(random.choice(alphabet) for i in range(16))
    await interaction.response.send_message(f"Random seed: `{random_seed}`", ephemeral=True)

@client.tree.command(name="skin", description="View a player's skin")
@app_commands.describe(player_name="Player from which to obtain the skin")
async def skin(interaction: discord.Interaction, player_name: str):
    # Ottieni l'UUID del giocatore
    url = f"https://api.mojang.com/users/profiles/minecraft/{player_name}"
    response = requests.get(url)
    if response.status_code == 200:
        player_data = response.json()
        player_uuid = player_data["id"]
    else:
        await interaction.response.send_message(f"Unable to find player {player_name}", ephemeral=True)
        return

    # Ottieni l'immagine della skin del giocatore
    skin_url = f"https://crafatar.com/renders/body/{player_uuid}?overlay"
    embed_mc = discord.Embed(title=f"Skin of {player_name}", color=discord.Color.green())
    embed_mc.set_image(url=skin_url)
    embed_mc.set_footer(icon_url=ICONTBS, text="Powered by TBS")

    # Invia l'immagine come embed
    await interaction.response.send_message(embed=embed_mc, ephemeral=True)

@client.tree.command(name="remindme", description="Create a reminder")
@app_commands.describe(seconds="secondi (ex. 3)", minutes="minutes (ex. 1)", hours="hours (ex. 4)", days="days (ex. 2)", reminder="reminder (ex. It's 8.00)")
async def remindme(interaction: discord.Interaction, seconds: int = 0, minutes: int = 0, hours: int = 0, days: int = 0, *, reminder: str):

    total_seconds = seconds + minutes * 60 + hours * 3600 + days * 86400

    if total_seconds == 0:
        await interaction.response.send_message(f"Reminder set", ephemeral=True)
        await interaction.user.send(f"{interaction.user.mention}, here is the reminder you set: ```{reminder}```")
        return

    user_id = str(interaction.user.id)
    conn = sqlite3.connect("reminders.db")
    db_cursor = conn.cursor()
    db_cursor.execute("CREATE TABLE IF NOT EXISTS reminders (user_id INTEGER, time INTEGER, reminder TEXT)")
    db_cursor.execute("INSERT INTO reminders (user_id, time, reminder) VALUES (?, ?, ?)", (user_id, total_seconds, reminder))
    conn.commit()
    conn.close()

    minutes, seconds = divmod(total_seconds, 60)
    hours, minutes = divmod(minutes, 60)
    days, hours = divmod(hours, 24)

    time_str = ""
    if days:
        time_str += f"{days} giorni "
    if hours:
        time_str += f"{hours} ore "
    if minutes:
        time_str += f"{minutes} minuti "
    if seconds:
        time_str += f"{seconds} secondi "

    await interaction.response.send_message(f"Reminder set. I will remember you: `{reminder}` in {time_str}.", ephemeral=True)

    await asyncio.sleep(total_seconds)
    if total_seconds == 0:
        await interaction.user.send(f"{interaction.user.mention}, here is the reminder you set: ```{reminder}```")
    else:
        await interaction.user.send(f"{interaction.user.mention}, here's the reminder you set **{time_str} ago**: ```{reminder}```")

@client.tree.command(name="server-icon", description="Displays the server icon")
async def servericon(interaction: discord.Interaction):
    server = interaction.guild
    # Ottieni l'immagine del server
    server_icon_url = str(server.icon.url) if server.icon else None
    if not server_icon_url:
        await interaction.response.send_message("No server images available", ephemeral=True)
        return

    embed = discord.Embed(title=f"Server image {server.name}", color=discord.Color.yellow())
    embed.add_field(name="Avatar", value=f"[Avatar URL]({str(server.icon.url)})")
    embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")
    embed.set_image(url=server_icon_url)
    await interaction.response.send_message(embed=embed, ephemeral=True)

@client.tree.command(name="server-info", description="View server information")
async def serverinfo(interaction: discord.Interaction):
    server = interaction.guild

    # Ottieni le informazioni del server
    server_name = server.name
    total_members = server.member_count
    server_created_at = server.created_at.strftime("%Y-%m-%d %H:%M:%S")
    server_owner = server.owner

    # Conteggio dei canali totali
    total_channels = len(server.channels)
    
    # Conteggio dei canali vocali
    voice_channels = sum(1 for channel in server.channels if channel.type == discord.ChannelType.voice)

    # Conteggio dei canali di testo
    text_channels = sum(1 for channel in server.channels if channel.type == discord.ChannelType.text)


    # Lista delle menzioni dei ruoli del server
    role_mentions = [role.mention for role in server.roles]

    # Aggiunta delle menzioni dei ruoli all'embed
    roles_str = len(role_mentions)

    # Ottieni l'immagine del server
    server_icon_url = str(server.icon.url) if server.icon else None

    # Crea l'embed di Discord
    embed = discord.Embed(title=f"Information about the {server_name} server", color=discord.Color.blue())
    embed.add_field(name="Total members 🔢", value=total_members, inline=False)
    embed.add_field(name="Server creation date 📅", value=server_created_at, inline=False)
    embed.add_field(name="Server owner 👑", value=server_owner.mention, inline=False)
    embed.add_field(name="Total roles ⚙️", value=roles_str, inline=True)
    embed.add_field(name="Total channels", value=total_channels, inline=False)
    embed.add_field(name="Vocal channels", value=voice_channels, inline=False)
    embed.add_field(name="Text channels", value=text_channels, inline=False)
    embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")
    
    if server_icon_url:
        embed.set_thumbnail(url=server_icon_url)
    else:
        embed.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)

    await interaction.response.send_message(embed=embed, ephemeral=True)

@client.tree.command(name="user-info", description="Visualizza le informazioni di un utente")
@app_commands.describe(member="Utente dalla quale visualizzare le info")
async def userinfo(interaction: discord.Interaction, member: discord.Member = None):
    member = member or interaction.user

    roles = ", ".join([role.mention for role in member.roles if role != interaction.guild.default_role])

    status = member.status
    if status == discord.Status.online:
        status_color = discord.Color.green()
    elif status == discord.Status.offline:
        status_color = discord.Color.red()
    elif status == discord.Status.idle:
        status_color = discord.Color.orange()
    elif status == discord.Status.dnd:
        status_color = discord.Color.dark_red()
    else:
        status_color = discord.Color.default()

    activity = member.activity.name if member.activity else "Nessuna attività in corso"

    embed_user = discord.Embed(title=f"Informazioni su {member}", color=status_color)
    embed_user.set_thumbnail(url=member.avatar.url)
    embed_user.add_field(name="Nome", value=member.name, inline=False)
    embed_user.add_field(name="Tag", value=member.discriminator, inline=False)
    embed_user.add_field(name="ID", value=member.id, inline=False)
    embed_user.add_field(name="Account creato il", value=member.created_at.strftime("%d/%m/%Y %H:%M:%S"), inline=False)
    embed_user.add_field(name="Entrato nel server il", value=member.joined_at.strftime("%d/%m/%Y %H:%M:%S"), inline=False)
    embed_user.add_field(name="Stato", value=str(status).capitalize(), inline=False)
    embed_user.add_field(name="Attività", value=activity, inline=False)
    embed_user.add_field(name="Ruoli", value=roles, inline=False)
    embed_user.set_footer(icon_url=ICONTBS, text="Powered by TBS")

    await interaction.response.send_message(embed=embed_user, ephemeral=True)

@client.tree.command(name="ping", description="Visualizza il ping del bot")
async def ping(interaction: discord.Interaction):
    latency = round(client.latency * 1000)
    await interaction.response.send_message(f"Pong!🏓 Latenza: _{latency}_ ms", ephemeral=True)

@client.tree.command(name="banner", description="Show the user's banner")
@app_commands.describe(member="User whose banner you want to see")
async def banner(interaction: discord.Interaction, member: discord.Member = None):
    # Se l'utente non è specificato, usa l'utente che ha eseguito il comando
    user = member or interaction.user

    try:
        # Ottieni l'utente dal server per ottenere il banner
        user = await client.fetch_user(user.id)

        # Ottieni il banner dell'utente
        banner_url = user.banner.url if user.banner else None

        if banner_url:
            embed = discord.Embed(
                title=f"Banner",
                description=f"[Banner url]({banner_url})",
                color=discord.Color.blue()
            )
            embed.set_image(url=banner_url)
            embed.set_author(name=f"{user.name}", icon_url=user.avatar.url)
            await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message(f"L'utente {user.name} non ha un banner", ephemeral=True)
    except discord.NotFound:
        await interaction.response.send_message("Utente non trovato", ephemeral=True)

@client.tree.command(name="avatar", description="Show the user's avatar")
@app_commands.describe(member="User whose avatar you want to see")
async def avatar(interaction: discord.Interaction, member: discord.Member = None):
    user = member or interaction.user

    try:
        # Ottieni l'utente dal server per ottenere il banner
        user = await client.fetch_user(user.id)

        # Ottieni il banner dell'utente
        avatar_url = user.avatar.url

        if avatar_url:
            embed = discord.Embed(
                title=f"Avatar",
                description=f"[Avatar url]({avatar_url})",
                color=discord.Color.blue()
            )
            embed.set_image(url=avatar_url)
            embed.set_author(name=f"{user.name}", icon_url=user.avatar.url)
            await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message(f"L'utente {user.name} non ha un banner", ephemeral=True)
    except discord.NotFound:
        await interaction.response.send_message("Utente non trovato", ephemeral=True)

@client.tree.command(name="info-boosts", description="Visualizza le informazioni sul boost del server")
async def info_boosts(interaction: discord.Interaction):
    server = interaction.guild

    server_icon_url = str(server.icon.url) if server.icon else None

    boost_count = server.premium_subscription_count
    boosters = [member for member in server.members if member.premium_since is not None]
    
    embed = discord.Embed(title=f"Potenziamenti del Server <a:3068newnitroboost:1164634714263519243>", color=discord.Color.pink())
    embed.add_field(name="Numero di Potenziamenti <a:nitroboost:1163905297266507836>", value=f"{boost_count}", inline=False)
    embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        
    if server_icon_url:
        embed.set_thumbnail(url=server_icon_url)
    else:
        embed.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
    
    if boosters:
        boosters_info = ""
        for member in boosters:
            boosts = len([boost for boost in server.premium_subscribers if boost.id == member.id])
            boosters_info += f"{member.mention} - {boosts} boost{'s' if boosts != 1 else ''}\n"
        embed.add_field(name="Boosters", value=boosters_info, inline=False)
    else:
        embed.add_field(name="Boosters", value="Nessun booster al momento", inline=False)
    
    await interaction.response.send_message(embed=embed, ephemeral=True)

@tbsstaff.command(name="ban", description="Banna un utente")
@app_commands.describe(member="Utente da bannare", reason="Motivo del ban")
async def ban(interaction: discord.Interaction, member: discord.Member, *, reason: str):
    server = interaction.guild

    server_icon_url = str(server.icon.url) if server.icon else None

    if interaction.user.guild_permissions.ban_members or interaction.user.guild_permissions.administrator:

        await member.ban(reason=reason)
        
        embedban = discord.Embed(title="New Ban <:Bannicon:1165713026452816073>", color=discord.Color.yellow())
        embedban.add_field(name="Utente Bannato :bust_in_silhouette:", value=member.mention, inline=False)
        embedban.add_field(name="Bannato da <:Staff:1164636542103474296>", value=interaction.user.mention, inline=False)
        embedban.add_field(name="Motivo <:forum_badge:1163093841029628000>", value=reason, inline=False)
        embedban.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        
        if server_icon_url:
            embedban.set_thumbnail(url=server_icon_url)
        else:
            embedban.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
        
        await interaction.response.send_message(embed=embedban)

    else:

        embednoperm = discord.Embed(title="No perms <:Staff:1164636542103474296>", description="Non hai il permesso (administrator or ban_members) per eseguire questo comando", color=discord.Color.red())
        embednoperm.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        
        if server_icon_url:
            embednoperm.set_thumbnail(url=server_icon_url)
        else:
            embednoperm.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)

        await interaction.response.send_message(embed=embednoperm, ephemeral=True)

@tbsstaff.command(name="kick", description="Espelli un utente")
@app_commands.describe(member="Utente che vuoi kickare", reason="Motivo del kick")
async def kick(interaction: discord.Interaction, member: discord.Member, *, reason: str):
    server = interaction.guild

    server_icon_url = str(server.icon.url) if server.icon else None

    if interaction.user.guild_permissions.kick_members or interaction.user.guild_permissions.ban_members or interaction.user.guild_permissions.administrator:
        await member.kick(reason=reason)
        
        embedkick = discord.Embed(title="New Kick <:Bannicon:1165713026452816073>", color=discord.Color.yellow())
        embedkick.add_field(name="Utente Kickato :bust_in_silhouette:", value=member.mention, inline=False)
        embedkick.add_field(name="Kickato da <:Staff:1164636542103474296>", value=interaction.user.mention, inline=False)
        embedkick.add_field(name="Motivo <:forum_badge:1163093841029628000>", value=reason, inline=False)
        embedkick.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        
        if server_icon_url:
            embedkick.set_thumbnail(url=server_icon_url)
        else:
            embedkick.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
        
        await interaction.response.send_message(embed=embedkick)
    else:
        embednopermkick = discord.Embed(title="No perms <:Staff:1164636542103474296>", description="Non hai il permesso (administrator or kick_members) per eseguire questo comando", color=discord.Color.red())
        embednopermkick.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        
        if server_icon_url:
            embednopermkick.set_thumbnail(url=server_icon_url)
        else:
            embednopermkick.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)

        await interaction.response.send_message(embed=embednopermkick, ephemeral=True)

@tbsstaff.command(name="timeout", description="Metti in timeout un utente")
@app_commands.describe(member="Utente che vuoi mettere in timeout", time="Tempo da mettere in timeout", reason="Motivo del timeout")
async def timeout(interaction: discord.Interaction, member: discord.Member, *, time: str, reason: str):
    server = interaction.guild

    server_icon_url = str(server.icon.url) if server.icon else None

    if interaction.user.guild_permissions.moderate_members or interaction.user.guild_permissions.administrator:

        if not time:
            time == '1d'

        try:
            real_duration = parse_timespan(time)
        except InvalidTimespan:
            await interaction.response.send_message(f"{time} non è un opzione valida, le opzione valide devono essere un numero, ad esempio:(2s, 4m, 3d etc)")
        else:

            try: 
                await member.timeout(Utils.utcnow() + timedelta(seconds=real_duration), reason=reason)
                
            except:
                await interaction.response.send_message(f"Non ho il permesso di mettere in timeout {member}")

            else:
                embedtimeout = discord.Embed(title="New timeout <:timeout_clock:1165739841443610654>", color=discord.Color.yellow())
                embedtimeout.add_field(name="Utente in timeout :bust_in_silhouette:", value=member.mention, inline=False)
                embedtimeout.add_field(name="timeoutato da <:Staff:1164636542103474296>", value=interaction.user.mention, inline=False)
                embedtimeout.add_field(name="Durata <a:loading:1163905279423959060>", value=time, inline=False)
                embedtimeout.add_field(name="Motivo <:forum_badge:1163093841029628000>", value=reason, inline=False)
                embedtimeout.set_footer(icon_url=ICONTBS, text="Powered by TBS")
                
                if server_icon_url:
                    embedtimeout.set_thumbnail(url=server_icon_url)
                else:
                    embedtimeout.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
                
                await interaction.response.send_message(embed=embedtimeout)
    else:
        embednopermtimeout = discord.Embed(title="No perms <:Staff:1164636542103474296>", description="Non hai il permesso (administrator or moderate_members) per eseguire questo comando", color=discord.Color.red())
        embednopermtimeout.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        
        if server_icon_url:
            embednopermtimeout.set_thumbnail(url=server_icon_url)
        else:
            embednopermtimeout.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)

        await interaction.response.send_message(embed=embednopermtimeout, ephemeral=True)

@tbsstaff.command(name="untimeout", description="Rimuovi il timeout ad un utente")
@app_commands.describe(member="Utente che vuoi togliere il timeout",  reason="Motivo dell'untimeout")
async def untimeout(interaction: discord.Interaction, member: discord.Member, *, reason: str):
    server = interaction.guild

    server_icon_url = str(server.icon.url) if server.icon else None

    if interaction.user.guild_permissions.moderate_members or interaction.user.guild_permissions.administrator:

        try: 
            await member.timeout(Utils.utcnow() + timedelta(seconds=0), reason=reason)
                
        except:
            await interaction.response.send_message(f"Non ho il permesso di togliere il timeout a {member}", ephemeral=True)

        else:

            embeduntimeout = discord.Embed(title="New untimeout <:timeout_clock:1165739841443610654>", color=discord.Color.yellow())
            embeduntimeout.add_field(name="Utente untimeouttato :bust_in_silhouette:", value=member.mention, inline=False)
            embeduntimeout.add_field(name="untimeoutato da <:Staff:1164636542103474296>", value=interaction.user.mention, inline=False)
            embeduntimeout.add_field(name="Motivo <:forum_badge:1163093841029628000>", value=reason, inline=False)
            embeduntimeout.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            
            if server_icon_url:
                embeduntimeout.set_thumbnail(url=server_icon_url)
            else:
                embeduntimeout.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
            
            await interaction.response.send_message(embed=embeduntimeout)
    else:

        embednopermuntimeout = discord.Embed(title="No perms <:Staff:1164636542103474296>", description="Non hai il permesso (administrator or moderate_members) per eseguire questo comando", color=discord.Color.red())
        embednopermuntimeout.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        
        if server_icon_url:
            embednopermuntimeout.set_thumbnail(url=server_icon_url)
        else:
            embednopermuntimeout.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)

        await interaction.response.send_message(embed=embednopermuntimeout, ephemeral=True)

@client.command()
@commands.cooldown(1, 10, commands.BucketType.user)
async def nitro_gen(interaction: discord.Interaction):
    global number_nitro_gen

    server = interaction.guild

    server_icon_url = str(server.icon.url) if server.icon else None

    # Verifica l'ID del server (gilda)
    allowed_guild_id = 1158829802690727988  # Sostituisci con l'ID della tua gilda

    if interaction.guild.id != allowed_guild_id:
        # Genera l'URL di invito per la tua gilda Discord
        server_icon_url_no_server = "https://cdn.discordapp.com/icons/1158829802690727988/a_6f26ea684f187000eb64af41e6197be2.gif?size=1024"

        embednitroerrorserver = discord.Embed(title="Nitro Gen Error <:NeonRedWarning:1163094574072340561>", color=discord.Color.red())
        embednitroerrorserver.add_field(name="Error", value=f"Questo comando è disponibile solo nel nostro server. Unisciti a noi cliccando [qui]({invite_url_tbs})", inline=False)
        embednitroerrorserver.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        
        if server_icon_url_no_server:
            embednitroerrorserver.set_thumbnail(url=server_icon_url_no_server)
        else:
            embednitroerrorserver.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
            
        # Invia il messaggio di errore e attendi un po' prima di eliminarlo
        await interaction.message.delete()
        await interaction.send(embed=embednitroerrorserver, delete_after=5)
        return


    # ID del canale corretto
    correct_channel_id = 1175738297058852905
    staff_role = interaction.guild.get_role(int("1166036820262387764"))
    vip_role = interaction.guild.get_role(int("1160511908168859678"))
    vip_boost_role = interaction.guild.get_role(int("1159154911339106434"))
    
    # Verifica se il comando viene eseguito nel canale corretto
    if interaction.channel.id != correct_channel_id:
        # Ottieni il nome del canale corretto
        correct_channel = interaction.guild.get_channel(correct_channel_id)
        
        # Costruisci il messaggio di errore con il nome del canale e un link di reindirizzamento
        error_message = f"Questo comando può essere eseguito solo nel canale {correct_channel.mention}."
        
        embednitroerrorchannel = discord.Embed(title="Nitro Gen Error <:NeonRedWarning:1163094574072340561>", color=discord.Color.red())
        embednitroerrorchannel.add_field(name="Error", value=error_message, inline=False)
        embednitroerrorchannel.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        
        if server_icon_url:
            embednitroerrorchannel.set_thumbnail(url=server_icon_url)
        else:
            embednitroerrorchannel.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
        
        # Invia il messaggio di errore e attendi un po' prima di eliminarlo
        await interaction.send(embed=embednitroerrorchannel, delete_after=3)
        await asyncio.sleep(2)  # Aspetta 2 secondi prima di eliminare l'embed e il messaggio del comando
        await interaction.message.delete()  # Elimina il messaggio del comando
        return

    if vip_boost_role in interaction.author.roles:
        num_nitro_codes = 5

    elif vip_role in interaction.author.roles:
        num_nitro_codes = 3  

    elif staff_role in interaction.author.roles:
        num_nitro_codes = 6

    else:
        probabilities = [0.6, 0.3, 0.1]  # 20% di probabilità per 1 codice, 30% per 2 codici, 50% per 3 codici
        num_nitro_codes = random.choices([1, 2, 3], probabilities)[0]
    
    codes = []
    for _ in range(num_nitro_codes):
        code = 'https://discord.gift/' + ''.join(random.choice("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890") for _ in range(16))
        codes.append(code)

        # Incrementa il contatore
        number_nitro_gen += 1

        # Salva il nuovo valore di number_nitro_gen nel file JSON
        with open("number_nitro_gen.json", "w") as file:
            json.dump(number_nitro_gen, file)

    try:
        
        embednitro = discord.Embed(title="Nitro Gen <a:3068newnitroboost:1164634714263519243>", description="Controlla i tuoi dm", color=discord.Color.yellow())
        embednitro.add_field(name="Numero codici <:Award_Icon:1163094204621262968>", value=num_nitro_codes, inline=False)
        embednitro.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        if server_icon_url:
            embednitro.set_thumbnail(url=server_icon_url)
        else:
            embednitro.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)

        
        await interaction.send(embed=embednitro, delete_after=3)

        time.sleep(2)
        await interaction.message.delete()

        # Invia i codici tramite messaggio diretto (DM)
        for code in codes:
            await interaction.author.send(f"||{code}||")

    except discord.Forbidden:
        embednitroerror = discord.Embed(title="Nitro Gen Error <:NeonRedWarning:1163094574072340561>", color=discord.Color.red())
        embednitroerror.add_field(name="Error", value="Non posso inviarti messaggi privati. Assicurati di avere i messaggi diretti (DM) abilitati", inline=False)
        embednitroerror.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        if server_icon_url:
            embednitroerror.set_thumbnail(url=server_icon_url)
        else:
            embednitroerror.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
        
        await interaction.send(embed=embednitroerror, delete_after=3)
        time.sleep(2)
        await interaction.message.delete()

# Gestisci l'errore specifico quando un utente esegue il comando durante il cooldown
@nitro_gen.error
async def nitro_gen_error(interaction: discord.Interaction, error):
    if isinstance(error, commands.CommandOnCooldown):
        server = interaction.guild

        server_icon_url = str(server.icon.url) if server.icon else None

        embednitroerror = discord.Embed(title="Nitro Gen Error <:NeonRedWarning:1163094574072340561>", color=discord.Color.red())
        embednitroerror.add_field(name="Error", value=f"Devi aspettare ancora {error.retry_after:.2f} secondi prima di poter eseguire di nuovo questo comando", inline=False)
        embednitroerror.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        
        if server_icon_url:
            embednitroerror.set_thumbnail(url=server_icon_url)
        else:
            embednitroerror.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
        
        await interaction.send(embed=embednitroerror, delete_after=3)
        time.sleep(2)
        await interaction.message.delete()


@tbsstaff.command(name="purge", description="Cancella un numero specifico di messaggi nel canale")
@app_commands.describe(amount="Numero di messaggi da cancellare")
async def purge(interaction: discord.Interaction, amount: int):
    server = interaction.guild

    server_icon_url = str(server.icon.url) if server.icon else None

    if interaction.user.guild_permissions.manage_messages or interaction.user.guild_permissions.administrator or interaction.user.guild_permissions.manage_guild:

        try:
            await interaction.response.send_message(f"Sto eliminando {amount} messaggi", ephemeral=True)

            await interaction.channel.purge(limit=amount)  # +1 per includere anche il messaggio del comando
        except Exception as e:
            print(e)  # Stampa l'errore nella console per il debug
            await interaction.response.send_message(f"Errore durante l'esecuzione del comando: {e}", ephemeral=True)

    else:
        embedpurgeerror = discord.Embed(title="Purge Error", color=discord.Color.green())
        embedpurgeerror.add_field(name="Error", value="Non hai il permesso (administrator or manage_guild or manage_messages) per eseguire questo comando", inline=False)
        embedpurgeerror.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            
        if server_icon_url:
            embedpurgeerror.set_thumbnail(url=server_icon_url)
        else:
            embedpurgeerror.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
            
        await interaction.response.send_message(embed=embedpurgeerror)

#@tbs.command(name="oauth2", description="Genera un link oauth2 del bot tramite le API")
#async def oauth2(interaction: discord.Interaction):
#
#    await interaction.response.send_message("⌛ Controllando i requisiti...", ephemeral=True)
#
#    await interaction.edit_original_response(content="⌛ Requisiti controllati...")
#    await asyncio.sleep(0.3)
#    await interaction.edit_original_response(content="⌛ Controllando i permessi...")
#    await asyncio.sleep(0.3)
#    await interaction.edit_original_response(content="⌛ Permessi controllati...")
#    await asyncio.sleep(0.3)
#    await interaction.edit_original_response(content="⌛ Connettendo con l\'API di discord")
#    await asyncio.sleep(0.3)
#    await interaction.edit_original_response(content="⌛ Errore nella connessione riprovo...")
#    await asyncio.sleep(0.3)
#    await interaction.edit_original_response(content="⌛ Connessione eseguita...")
#    await asyncio.sleep(0.3)
#    await interaction.edit_original_response(content="⌛ Accedendo tramite richieste...")
#    await asyncio.sleep(0.3)
#    await interaction.edit_original_response(content="⌛ Accesso eseguito...")
#    await asyncio.sleep(0.3)
#    await interaction.edit_original_response(content="⌛ Creando il link tramite API...")
#    await asyncio.sleep(0.3)
#    await interaction.edit_original_response(content="⌛ Link tramite API creato...")
#
#    await asyncio.sleep(0.7)
#    
#    await interaction.edit_original_response(content=f"👻 Ecco il link dell\'API\nhttps://discord.com/api/oauth2/authorize?client_id={client_id}&redirect_uri={redirect_uri}&response_type=code&scope=email%20guilds.join%20identify%20guilds%20rpc%20connections")

@client.command(name='joinall')
async def add_to_guild(interaction: discord.Interaction, guild_id: str):
    await interaction.message.delete()

    # Verifica l'ID del server (gilda)
    allowed_guild_id = 1158829802690727988  # Sostituisci con l'ID della tua gilda

    if interaction.guild.id == allowed_guild_id:
        if interaction.author.guild_permissions.administrator:

            msg = await interaction.send("Sto caricando i membri...")
            time.sleep(1)

            # Carica i dati dal file JSON
            with open('info_token.json', 'r') as file:
                user_data = json.load(file)

            await msg.edit(content="Membri caricati, iniziando processo di unione")

            for user_info in user_data:
                user_id = user_info['id']
                access_token = user_info['access_token']
                
                tkn = Token

                url = f"https://discord.com/api/v10/guilds/{guild_id}/members/{user_id}"
                botToken = tkn
                data = {
                "access_token" : access_token,
                }
                headers = {
                    "Authorization": f"Bot {botToken}",
                    "Content-Type": "application/json"
                }
                data = {
                    "access_token": access_token,
                }

                requests.put(url=url, headers=headers, json=data)

            await msg.edit(content="Operazione completata!")
            time.sleep(1)
            await msg.delete()

        else:
            await interaction.send("Non hai il permesso!", delete_after=2)
    else:
        await interaction.send("Non hai il permesso oppure non è la gilda giusta!", delete_after=2)


@tbsgiveaway.command(name="create", description="Create giveaway")
@app_commands.describe(duration="Durata del giveaway (5m -> 5 minuti, 5s -> 5 secondi, 5d -> 5 giorni)", prize="Il premio del giveaway", description="Descrizione del giveaway")
async def giveaway(interaction: discord.Interaction, duration: str, prize: str, description: str = None):

    server = interaction.guild
    server_id = interaction.guild.id

    server_icon_url = str(server.icon.url) if server.icon else None

    if interaction.user.guild_permissions.manage_messages or interaction.user.guild_permissions.manage_events or interaction.user.guild_permissions.administrator:

        # Genera un numero casuale di 6 cifre come ID del giveaway
        giveaway_id = random.randint(1000, 9999)
        # Calcola il tempo di fine del giveaway
        # Converte la durata in secondi utilizzando humanfriendly
        duration_seconds = parse_timespan(duration)
        epochEnd = time.time() + duration_seconds
        
        # Crea l'embed del giveaway
        embed = discord.Embed(title='Giveaway Time! <:Award_Icon:1163094204621262968>', color=discord.Color.random())
        if description is not None:
            embed.description = description
        embed.add_field(name="Prize :gift:", value=f"_{prize}_", inline=False)
        embed.add_field(name="Host by <:admin_badge_turquoise:1164634645057503425>", value=interaction.user.mention, inline=False)
        embed.add_field(name='Duration :clock1:', value=f"<t:{int(epochEnd)}:R> / <t:{int(epochEnd)}:f>", inline=False)
        embed.set_author(name="TBS", icon_url=ICONTBS)
        embed.set_image(url="https://cdn.discordapp.com/attachments/1167209178515902515/1167343864634417232/tbs-giveaway.png?ex=654dc8b1&is=653b53b1&hm=f72ed455d0d712a4a7a8c2237a953895957d4dda5bb809051c4897990a527a7a&")
        embed.set_footer(icon_url=ICONTBS, text=f"Giveaway ID: {giveaway_id}")
        if server_icon_url:
            embed.set_thumbnail(url=server_icon_url)
        else:
            embed.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
        message = await interaction.response.send_message(embed=embed, view=GiveawayView(int(giveaway_id), int(server_id)))

        conn = sqlite3.connect("giveaways.db")
        c = conn.cursor()

        # Creare la tabella se non esiste
        c.execute('''CREATE TABLE IF NOT EXISTS giveaways
                    (id INTEGER PRIMARY KEY AUTOINCREMENT, server_id INTEGER, giveaway_id INTEGER, prize TEXT, duration INTEGER, participants TEXT)''')

        # Salva le informazioni del giveaway nel database
        c.execute("INSERT INTO giveaways (server_id, giveaway_id, prize, duration, participants) VALUES (?, ?, ?, ?, ?)",
                (server_id, giveaway_id, prize, duration_seconds, ""))

        # Conferma le modifiche nel database
        conn.commit()
        conn.close()

        # Avvia il timer del giveaway
        await asyncio.sleep(duration_seconds)
        
        # Ottiene tutti i partecipanti dal database
        conn = sqlite3.connect("giveaways.db")
        c = conn.cursor()
        # Quando recuperi i dati dal database
        c.execute("SELECT participants FROM giveaways WHERE server_id = ? AND giveaway_id = ?", (server_id, giveaway_id))
        participants_data = c.fetchone()

        if participants_data and participants_data[0]:
            participants = json.loads(participants_data[0])  # Converti i partecipanti in una lista
        else:
            participants = []


        conn.close()


        # Sceglie casualmente un vincitore tra i partecipanti
        winner_id = random.choice(list(participants)) if participants else None

        # Calcola il numero di partecipanti
        num_participants = len(participants)
        
        # Modifica l'embed esistente per indicare che il giveaway è terminato
        async for message in interaction.channel.history(limit=None):
            # Verifica se il messaggio ha un embed
            if message.embeds:
                # Loop attraverso gli embed nel messaggio
                for embed in message.embeds:
                    # Controlla se il footer del embed contiene il giveaway_id
                    if embed.footer.text == f"Giveaway ID: {giveaway_id}":
                        embed.title = 'Giveaway Ended!'
                        embed.color = discord.Color.green()

                        # Aggiunge il campo del vincitore all'embed
                        if winner_id:
                            winner_member = interaction.guild.get_member(int(winner_id))
                            embed.add_field(name='Winner', value=winner_member.mention)
                        else:
                            embed.add_field(name='Winner', value='No one participated in the giveaway.')

                        embed.add_field(name="Entries", value=num_participants, inline=True)
                        view = discord.ui.View()
                        await message.edit(embed=embed, view=view)
                        await interaction.followup.send(f"The winner is <@{winner_id}> 🎉🎉🎉")
                        break

    else:
        embedgiveawayerror = discord.Embed(title="Giveaway Error", color=discord.Color.red())
        embedgiveawayerror.add_field(name="Error", value="Non hai il permesso (administrator or manage_events or manage_messages) per eseguire questo comando", inline=False)
        embedgiveawayerror.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            
        if server_icon_url:
            embedgiveawayerror.set_thumbnail(url=server_icon_url)
        else:
            embedgiveawayerror.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
            
        await interaction.response.send_message(embed=embedgiveawayerror, ephemeral=True)


@tbsgiveaway.command(name="roll", description="Rolla un giveaway")
@app_commands.describe(giveaway_id="L'id del giveaway creato, mostrato nel footer del giveaway")
async def roll(interaction: discord.Interaction, giveaway_id: str):

    server = interaction.guild
    server_id = interaction.guild.id

    server_icon_url = str(server.icon.url) if server.icon else None

    if interaction.user.guild_permissions.manage_messages or interaction.user.guild_permissions.manage_events or interaction.user.guild_permissions.administrator:

        # Ottiene tutti i partecipanti dal database
        conn = sqlite3.connect("giveaways.db")
        c = conn.cursor()
        # Quando recuperi i dati dal database
        c.execute("SELECT participants FROM giveaways WHERE server_id = ? AND giveaway_id = ?", (server_id, giveaway_id))
        participants_data = c.fetchone()

        if participants_data and participants_data[0]:
            participants = json.loads(participants_data[0])  # Converti i partecipanti in una lista
        else:
            participants = []

        conn.close()

        # Sceglie casualmente un vincitore tra i partecipanti
        winner_id = random.choice(list(participants)) if participants else None

        new_winner_id = random.choice(list(participants)) if participants else None

        # Modifica l'embed esistente per indicare che il giveaway è terminato
        async for message in interaction.channel.history(limit=300):
            # Verifica se il messaggio ha un embed
            if message.embeds:
                # Loop attraverso gli embed nel messaggio
                for embed in message.embeds:
                    # Controlla se il footer del embed contiene il giveaway_id
                    if embed.footer.text == f"Giveaway ID: {giveaway_id}":
                        embed.title = 'Giveaway Rolled!'
                        embed.color = discord.Color.green()

                        # Aggiunge il campo del vincitore all'embed
                        if new_winner_id:
                            winner_member = interaction.guild.get_member(int(new_winner_id))
                            embed.set_field_at(index=3, name='Winner', value=winner_member.mention)
                        else:
                            embed.set_field_at(index=3, name='Winner', value='No one participated in the giveaway.')

                        view = discord.ui.View()
                        await message.edit(embed=embed, view=view)
                        await interaction.response.send_message(f'**ROLLED BY: {interaction.user.mention}**!<:Staff:1164636542103474296>\n Nuovo vincitore del giveaway: <@{new_winner_id}> 🎉🎉🎉')
                        break

    else:
        embedgiveawayrollerror = discord.Embed(title="Giveaway Error", color=discord.Color.red())
        embedgiveawayrollerror.add_field(name="Error", value="Non hai il permesso (administrator or manage_events or manage_messages) per eseguire questo comando", inline=False)
        embedgiveawayrollerror.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            
        if server_icon_url:
            embedgiveawayrollerror.set_thumbnail(url=server_icon_url)
        else:
            embedgiveawayrollerror.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
            
        await interaction.response.send_message(embed=embedgiveawayrollerror, ephemeral=True)


@tbsgiveaway.command(name="delete", description="Elimina definitivamente un giveaway un giveaway")
@app_commands.describe(giveaway_id="L'id del giveaway creato, mostrato nel footer del giveaway")
async def del_giveaway(interaction: discord.Interaction, giveaway_id: str):

    server = interaction.guild

    server_icon_url = str(server.icon.url) if server.icon else None

    if interaction.user.guild_permissions.manage_messages or interaction.user.guild_permissions.manage_events or interaction.user.guild_permissions.administrator:
        # Ottiene il messaggio del giveaway e il canale dal message_id e channel_id forniti
        # Modifica l'embed esistente per indicare che il giveaway è terminato
        async for message in interaction.channel.history(limit=150):
            # Verifica se il messaggio ha un embed
            if message.embeds:
                # Loop attraverso gli embed nel messaggio
                for embed in message.embeds:
                    # Controlla se il footer del embed contiene il giveaway_id
                    if embed.footer.text == f"Giveaway ID: {giveaway_id}":

                        await message.delete()

        await interaction.response.send_message(f'Giveaway eliminato!', ephemeral=True)
    
    else:
        embedgiveawaydelerror = discord.Embed(title="Giveaway Error", color=discord.Color.red())
        embedgiveawaydelerror.add_field(name="Error", value="Non hai il permesso (administrator or manage_events or manage_messages) per eseguire questo comando", inline=False)
        embedgiveawaydelerror.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            
        if server_icon_url:
            embedgiveawaydelerror.set_thumbnail(url=server_icon_url)
        else:
            embedgiveawaydelerror.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
            
        await interaction.response.send_message(embed=embedgiveawaydelerror, ephemeral=True)

@tbsrole.command(name="all", description="Aggiunge il ruolo specificato a tutti i membri del server")
@app_commands.describe(role="Ruolo che vuoi assegnare a tutti i membri del server")
async def role_all(interaction: discord.Interaction, role: discord.Role):
    server = interaction.guild

    server_icon_url = str(server.icon.url) if server.icon else None

    if interaction.user.guild_permissions.administrator or interaction.user.guild_permissions.manage_roles or interaction.user.guild_permissions.manage_guild:
        members = interaction.guild.members
        members_to_assign_role = [member for member in members if role not in member.roles]
        success_count = 0
        error_count = 0

        message_roll = await interaction.response.send_message(f"Inizio assegnazione a {len(members_to_assign_role)} membri del server il ruolo: {role.mention}!", ephemeral=True)

        for member in members_to_assign_role:
            try:
                await member.add_roles(role)
                success_count += 1
            except discord.Forbidden:
                error_count += 1
            except discord.HTTPException as e:
                error_count += 1

        embedroleall = discord.Embed(title="Role-all Completed", color=discord.Color.green())
        embedroleall.add_field(name="User", value=len(members_to_assign_role), inline=False)
        embedroleall.add_field(name="Success", value=int(success_count), inline=False)
        embedroleall.add_field(name="Failed", value=int(error_count), inline=False)
        embedroleall.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            
        if server_icon_url:
            embedroleall.set_thumbnail(url=server_icon_url)
        else:
            embedroleall.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
            
        follow_up_success = await interaction.followup.send(embed=embedroleall, ephemeral=True)

    else:
        embedroleallerror = discord.Embed(title="Role-all Error", color=discord.Color.red())
        embedroleallerror.add_field(name="Error", value="Non hai il permesso (administrator or manage_roles or manage_guild) per eseguire questo comando", inline=False)
        embedroleallerror.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            
        if server_icon_url:
            embedroleallerror.set_thumbnail(url=server_icon_url)
        else:
            embedroleallerror.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
            
        await interaction.response.send_message(embed=embedroleallerror, ephemeral=True)

@tbsrall.command(name="all", description="Rimuove il ruolo specificato da tutti i membri del server")
@app_commands.describe(role="Ruolo che vuoi rimuovere a tutti gli utenti del server")
async def remove_role_all(interaction: discord.Interaction, role: discord.Role):
    server = interaction.guild

    server_icon_url = str(server.icon.url) if server.icon else None

    if interaction.user.guild_permissions.administrator or interaction.user.guild_permissions.manage_roles or interaction.user.guild_permissions.manage_guild:
        members = interaction.guild.members
        success_count = 0
        error_count = 0

        message_rall = await interaction.response.send_message(f"Inizio rimozione a {len(members)} membri del server il ruolo: {role.mention}!", ephemeral=True)

        for member in members:
            try:
                await member.remove_roles(role)
                success_count += 1
            except discord.Forbidden:
                error_count += 1
            except discord.HTTPException as e:
                error_count += 1

        embedrall = discord.Embed(title="Rall Completed", color=discord.Color.green())
        embedrall.add_field(name="User", value=len(members), inline=False)
        embedrall.add_field(name="Success", value=int(success_count), inline=False)
        embedrall.add_field(name="Failed", value=int(error_count), inline=False)
        embedrall.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            
        if server_icon_url:
            embedrall.set_thumbnail(url=server_icon_url)
        else:
            embedrall.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
            
        follow_up_success = await interaction.followup.send(embed=embedrall, ephemeral=True)

    else:
        embedrallerror = discord.Embed(title="Rall Error", color=discord.Color.red())
        embedrallerror.add_field(name="Error", value="Non hai il permesso (administrator or manage_roles or manage_guild) per eseguire questo comando", inline=False)
        embedrallerror.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            
        if server_icon_url:
            embedrallerror.set_thumbnail(url=server_icon_url)
        else:
            embedrallerror.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
            
        await interaction.response.send_message(embed=embedrallerror, ephemeral=True)

@tbsrole.command(name="bot", description="Aggiunge il ruolo specificato a tutti i bot del server")
@app_commands.describe(role="Ruolo che vuoi assegnare a tutti i bot del server")
async def role_bot(interaction: discord.Interaction, role: discord.Role):
    server = interaction.guild

    server_icon_url = str(server.icon.url) if server.icon else None

    if interaction.user.guild_permissions.administrator or interaction.user.guild_permissions.manage_roles or interaction.user.guild_permissions.manage_guild:
        members = interaction.guild.members
        bot_members = [member for member in interaction.guild.members if member.bot]
        success_count = 0
        error_count = 0

        message_roll_bot = await interaction.response.send_message(f"Inizio assegnazione a {len(bot_members)} bot del server il ruolo: {role.mention}!", ephemeral=True)

        for member in bot_members:
            try:
                await member.add_roles(role)
                success_count += 1
            except discord.Forbidden:
                error_count += 1
            except discord.HTTPException as e:
                error_count += 1

        embedroleallbot = discord.Embed(title="Role-bot Completed", color=discord.Color.green())
        embedroleallbot.add_field(name="Bot", value=len(bot_members), inline=False)
        embedroleallbot.add_field(name="Success", value=int(success_count), inline=False)
        embedroleallbot.add_field(name="Failed", value=int(error_count), inline=False)
        embedroleallbot.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            
        if server_icon_url:
            embedroleallbot.set_thumbnail(url=server_icon_url)
        else:
            embedroleallbot.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
            
        follow_up_success = await interaction.followup.send(embed=embedroleallbot, ephemeral=True)

    else:
        embedroleallboterror = discord.Embed(title="Role-bot Error", color=discord.Color.red())
        embedroleallboterror.add_field(name="Error", value="Non hai il permesso (administrator or manage_roles or manage_guild) per eseguire questo comando", inline=False)
        embedroleallboterror.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            
        if server_icon_url:
            embedroleallboterror.set_thumbnail(url=server_icon_url)
        else:
            embedroleallboterror.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
            
        await interaction.response.send_message(embed=embedroleallboterror, ephemeral=True)

@tbsrall.command(name="bot", description="Rimuovi il ruolo specificato a tutti i bot del server")
@app_commands.describe(role="Ruolo che vuoi rimuovere a tutti i bot del server")
async def rall_bot(interaction: discord.Interaction, role: discord.Role):
    server = interaction.guild

    server_icon_url = str(server.icon.url) if server.icon else None

    if interaction.user.guild_permissions.administrator or interaction.user.guild_permissions.manage_roles or interaction.user.guild_permissions.manage_guild:
        members = interaction.guild.members
        bot_members = [member for member in interaction.guild.members if member.bot]
        success_count = 0
        error_count = 0

        message_rall_bot = await interaction.response.send_message(f"Inizio rimozione a {len(bot_members)} bot del server il ruolo: {role.mention}!", ephemeral=True)

        for member in bot_members:
            try:
                await member.remove_roles(role)
                success_count += 1
            except discord.Forbidden:
                error_count += 1
            except discord.HTTPException as e:
                error_count += 1

        embedrallbot = discord.Embed(title="Rall-bot Completed", color=discord.Color.green())
        embedrallbot.add_field(name="Bot", value=len(bot_members), inline=False)
        embedrallbot.add_field(name="Success", value=int(success_count), inline=False)
        embedrallbot.add_field(name="Failed", value=int(error_count), inline=False)
        embedrallbot.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            
        if server_icon_url:
            embedrallbot.set_thumbnail(url=server_icon_url)
        else:
            embedrallbot.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
            
        follow_up_success = await interaction.followup.send(embed=embedrallbot, ephemeral=True)

    else:
        embedrallboterror = discord.Embed(title="Rall-bot Error", color=discord.Color.red())
        embedrallboterror.add_field(name="Error", value="Non hai il permesso (administrator or manage_roles or manage_guild) per eseguire questo comando", inline=False)
        embedrallboterror.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            
        if server_icon_url:
            embedrallboterror.set_thumbnail(url=server_icon_url)
        else:
            embedrallboterror.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
            
        await interaction.response.send_message(embed=embedrallboterror, ephemeral=True)

@tbsrole.command(name="add", description="Aggiunge il ruolo specificato al membro del server")
@app_commands.describe(member="Membro alla quale vuoi assegnare il ruolo", role="Ruolo che vuoi assegnare al membro del server")
async def role_add(interaction: discord.Interaction, member: discord.Member, role: discord.Role):
    server = interaction.guild

    server_icon_url = str(server.icon.url) if server.icon else None

    if interaction.user.guild_permissions.administrator or interaction.user.guild_permissions.manage_roles or interaction.user.guild_permissions.manage_guild:
        success_count = 0
        error_count = 0

        await interaction.response.send_message(f"Inizio assegnazione a {member.mention}il ruolo: {role.mention}!", ephemeral=True)
        
        if member:
            try:
                if role.position < max(r.position for r in member.roles):
                    await member.add_roles(role)
                    success_count += 1
                else:
                    error_count += 1
            except discord.Forbidden:
                error_count += 1
            except discord.HTTPException as e:
                error_count += 1

        embedroleadd = discord.Embed(title="Role-add Completed", color=discord.Color.green())
        embedroleadd.add_field(name="User", value=member.mention, inline=False)
        embedroleadd.add_field(name="Success", value=int(success_count), inline=False)
        embedroleadd.add_field(name="Failed", value=int(error_count), inline=False)
        embedroleadd.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            
        if server_icon_url:
            embedroleadd.set_thumbnail(url=server_icon_url)
        else:
            embedroleadd.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
            
        await interaction.followup.send(embed=embedroleadd, ephemeral=True)

    else:
        embedroleadderror = discord.Embed(title="Role-add Error", color=discord.Color.red())
        embedroleadderror.add_field(name="Error", value="Non hai il permesso (administrator or manage_roles or manage_guild) per eseguire questo comando", inline=False)
        embedroleadderror.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            
        if server_icon_url:
            embedroleadderror.set_thumbnail(url=server_icon_url)
        else:
            embedroleadderror.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
            
        await interaction.response.send_message(embed=embedroleadderror, ephemeral=True)

@tbsrole.command(name="remove", description="Rimuove il ruolo specificato ad un membro specificato del server")
@app_commands.describe(member="Membro alla quale vuoi rimuovere il ruolo", role="Ruolo che vuoi rimuovere al membro del server")
async def role_remove(interaction: discord.Interaction, member: discord.Member, role: discord.Role):
    server = interaction.guild

    server_icon_url = str(server.icon.url) if server.icon else None

    if interaction.user.guild_permissions.administrator or interaction.user.guild_permissions.manage_roles or interaction.user.guild_permissions.manage_guild:
        success_count = 0
        error_count = 0

        await interaction.response.send_message(f"Inizio rimozione a {member.mention}il ruolo: {role.mention}!", ephemeral=True)
        if member:
            try:
                # Verifica se il ruolo da rimuovere è inferiore al massimo ruolo dell'utente
                if role.position < max(r.position for r in member.roles):
                    await member.remove_roles(role)
                    success_count += 1
                else:
                    error_count += 1
            except discord.Forbidden:
                error_count += 1
            except discord.HTTPException as e:
                error_count += 1

        embedroleadd = discord.Embed(title="Role-remove Completed", color=discord.Color.green())
        embedroleadd.add_field(name="User", value=member.mention, inline=False)
        embedroleadd.add_field(name="Success", value=int(success_count), inline=False)
        embedroleadd.add_field(name="Failed", value=int(error_count), inline=False)
        embedroleadd.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            
        if server_icon_url:
            embedroleadd.set_thumbnail(url=server_icon_url)
        else:
            embedroleadd.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
            
        await interaction.followup.send(embed=embedroleadd, ephemeral=True)

    else:
        embedroleadderror = discord.Embed(title="Role-remove Error", color=discord.Color.red())
        embedroleadderror.add_field(name="Error", value="Non hai il permesso (administrator or manage_roles or manage_guild) per eseguire questo comando", inline=False)
        embedroleadderror.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            
        if server_icon_url:
            embedroleadderror.set_thumbnail(url=server_icon_url)
        else:
            embedroleadderror.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
            
        await interaction.response.send_message(embed=embedroleadderror, ephemeral=True)

@tbsstaff.command(name="annuncio", description="Crea un annuncio (interactive)")
async def annuncio(interaction: discord.Interaction):
    server = interaction.guild

    server_icon_url = str(server.icon.url) if server.icon else None

    if interaction.user.guild_permissions.administrator or interaction.user.guild_permissions.manage_messages or interaction.user.guild_permissions.manage_guild:
        annuncio_modal = AnnuncioModal()
        await interaction.response.send_modal(annuncio_modal)
    else:
        embedannuncioerror = discord.Embed(title="Annuncio Error", color=discord.Color.red())
        embedannuncioerror.add_field(name="Error", value="Non hai il permesso (administrator or manage_messages or manage_guild) per eseguire questo comando", inline=False)
        embedannuncioerror.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            
        if server_icon_url:
            embedannuncioerror.set_thumbnail(url=server_icon_url)
        else:
            embedannuncioerror.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
            
        await interaction.response.send_message(embed=embedannuncioerror, ephemeral=True)       

#@tbs.command(name="suggestion", description="Crea una suggestion")
#async def suggestion(interaction: discord.Interaction):
#
#    server = interaction.guild
#
#    server_icon_url = str(server.icon.url) if server.icon else None
#    
#    if interaction.guild.id == guild_id_tbs:
#        if interaction.channel.id == suggestion_channel_id:
#            suggestion_modal = SuggestionModal()
#            suggestion_modal.user = interaction.user
#            await interaction.response.send_modal(suggestion_modal)
#        else:
#            embedsuggestionerrorchannel = discord.Embed(title="Suggestion-Channel Error", color=discord.Color.red())
#            embedsuggestionerrorchannel.add_field(name="Error", value=f"Questo comando può essere utilizzato solo nel canale <#{suggestion_channel_id}>", inline=False)
#            embedsuggestionerrorchannel.set_footer(icon_url=ICONTBS, text="Powered by TBS")
#                
#            if server_icon_url:
#                embedsuggestionerrorchannel.set_thumbnail(url=server_icon_url)
#            else:
#                embedsuggestionerrorchannel.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
#                
#            await interaction.response.send_message(embed=embedsuggestionerrorchannel, ephemeral=True) 
#    else:
#        embedsuggestionerror = discord.Embed(title="Suggestion Error", color=discord.Color.red())
#        embedsuggestionerror.add_field(name="Error", value=f"Questo comando può esere usato solo nel server ufficiale: [TBS]({invite_url_tbs})", inline=False)
#        embedsuggestionerror.set_footer(icon_url=ICONTBS, text="Powered by TBS")
#            
#        if server_icon_url:
#            embedsuggestionerror.set_thumbnail(url=server_icon_url)
#        else:
#            embedsuggestionerror.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
#            
#        await interaction.response.send_message(embed=embedsuggestionerror, ephemeral=True) 

@client.tree.command(name="embed", description="Crea un embed (interactive)")
async def embed_create(interaction: discord.Interaction):
    server = interaction.guild

    server_icon_url = str(server.icon.url) if server.icon else None

    if interaction.user.guild_permissions.administrator or interaction.user.guild_permissions.manage_messages or interaction.user.guild_permissions.manage_guild:
        embed_modal = EmbedCreateModal()

        await interaction.response.send_modal(embed_modal)
    else:
        embedcreateerror = discord.Embed(title="Embed-Create Error", color=discord.Color.red())
        embedcreateerror.add_field(name="Error", value="Non hai il permesso (administrator or manage_messages or manage_guild) per eseguire questo comando", inline=False)
        embedcreateerror.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            
        if server_icon_url:
            embedcreateerror.set_thumbnail(url=server_icon_url)
        else:
            embedcreateerror.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
            
        await interaction.response.send_message(embed=embedcreateerror, ephemeral=True)     

@client.tree.command(name="current-server-invite", description="Generate a invite for the current server")
async def geninvite(interaction: discord.Interaction):
    inv = await interaction.channel.create_invite()
    await interaction.response.send_message("Click the button below to invite friend in this server!", view=InviteButtons(str(inv)), ephemeral=True)

@tbsstaff.command(name="verify-setup", description="Setta la verfica nel tuo server")
async def verify(interaction: discord.Interaction):
    server = interaction.guild

    server_icon_url = str(server.icon.url) if server.icon else None

    if interaction.user.guild_permissions.administrator or interaction.user.guild_permissions.manage_guild:
        await interaction.response.send_message("Per settare la verifica hai bisogno di aver nel server i ruoli Unverified e Verified", view=ButtonVerifySetup(), ephemeral=True)
    else:   
        embedverifyerror = discord.Embed(title="Verify-Setup Error", color=discord.Color.red())
        embedverifyerror.add_field(name="Error", value="Non hai il permesso (administrator or manage_guild) per eseguire questo comando", inline=False)
        embedverifyerror.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            
        if server_icon_url:
            embedverifyerror.set_thumbnail(url=server_icon_url)
        else:
            embedverifyerror.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
            
        await interaction.response.send_message(embed=embedverifyerror, ephemeral=True)  

@client.tree.command(name="roles", description="Tbs bot help")
async def roles(interaction: discord.Interaction):
    embeds = []
    for roles in discord.utils.as_chunks(interaction.guild.roles, 5):
        embed = discord.Embed(title="List of roles")
        for i in roles:
            embed.add_field(name=f"{i.name}", value=f"Total members - {len(i.members)}")
        embeds.append(embed)
    view = PaginatorView(embeds)
    await interaction.response.send_message(embed=view.initial, view=view)

@client.tree.command(name="help", description="Tbs bot help")
async def help_interaction(interaction: discord.Interaction):
    # Creare gli embeds per le pagine
    embed1 = discord.Embed(title="Description <:FAQ:1167871343082090615><:role_bot:1166369625882230854>", description=f"Description of the <@1166469227562160218> bot\n\n__**[Privacy Policy](https://github.com/MonkeyMoon104/bot-impostation/blob/main/privacy-policy)**__ - __**[Terms of Service](https://github.com/MonkeyMoon104/bot-impostation/blob/main/terms-of-service)**__ - __**[Tbs Status](https://tbsbot.statuspage.io)**__\n\n **COMMANDS**", color=discord.Color.yellow())
    embed1.add_field(name="Staff commands <:admin_badge_dark_blue:1164634577260777483><:commands:1167871344524931238>", value="`staff ban`, `staff kick`, `staff timeout`, `staff untimeout`, `staff verify-setup`, `staff embed`, `staff annuncio`, `staff automod`, `staff set-log-channel`, `staff edit-log-channel`, `staff delete-log-channel`, `staff nuke`", inline=False)
    embed1.add_field(name="Ticket commands <a:Nitro_pass_a:1175081966689857536>", value="`ticket setup`, `ticket add`, `ticket purge`", inline=False)
    embed1.add_field(name="Giveaway commands <:Award_Icon:1163094204621262968>", value="`giveaway create`, `giveaway delete`, `giveaway roll`")
    embed1.add_field(name="Role commands <:admin_badge_turquoise:1164634645057503425><:rules_badge:1163095703585837107>", value="`role info`, `role add`, `role all`, `role bot`, `role remove`, `rall all`, `rall bot`", inline=False)
    embed1.add_field(name="Emoji commands <:Community_Server_Public:1176637853950804030>", value="`emoji steal`", inline=False)
    embed1.add_field(name="Fortnite commands <:fortnite:1178771124864167997>", value="`fortnite news`, `fortnite map`, `fortnite shop`, `fortnite stats`", inline=False)
    embed1.add_field(name="Welcome commands <:join:1167890762453766288>", value="`welcome set`, `welcome edit`, `welcome delete`", inline=False)
    embed1.add_field(name="General <:forum_badge:1163093841029628000><:Members:1167344632691163196>", value="`help`, `invite`, `remindme`, `skin`, `avatar`, `info-boosts`, `ping`, `roles`, `seed-gen`, `server-icon`, `server-info`, `user-info`, `find-activity`, `streaming-users`, `live-twitch`, `check`, `report`, `discord-status`, `discord-status-voice`, `qrcode`, `ascii`, `status`, `topgg-bot`, `ig-details`, `spoiler`, `chat-gpt`, `cat`, `calculate`, `randomgif`", inline=False)
    embed1.add_field(name="TBS <:tbs:1167450187845873734>", value="To obtain assistance with our bot, report problems/malfunctions or anything else you can easily open a ticket on our server with the Bot Support category!", inline=False)
    embed1.set_footer(icon_url=ICONTBS, text="Powered by TBS")
    embed1.set_thumbnail(url=ICONTBS)

    # Invia il messaggio con la vista
    await interaction.response.send_message(embed=embed1, view=HelpCommandView(), ephemeral=True)

#    await interaction.response.send_message("Per verificarti clicca qui!", view=ButtonVerify())


#@client.command()
#async def nitro_info(interaction: discord.Interaction):
    #server = interaction.guild

    #server_icon_url = str(server.icon.url) if server.icon else None
        
    #embednitroerrorchannel = discord.Embed(title="Nitro Commands <a:nitroboost:1163905297266507836>", description="All bot commands\nif you don't have dm open, you won't be able to receive nitro in dm!", color=discord.Color.yellow())
    #embednitroerrorchannel.add_field(name="$nitro_gen", value="Generate a Nitro Code (Unchecked)", inline=False)
    #embednitroerrorchannel.add_field(name="INFORMATION", value="Users with the role <@&1159154911339106434> will receive **3 nitro codes (unchecked)**, others will receive 1\nIf you spamm the command you will ban!", inline=False)
    #embednitroerrorchannel.set_footer(icon_url=server_icon_url, text="Powered by TBS")
        
    #if server_icon_url:
        #embednitroerrorchannel.set_thumbnail(url=server_icon_url)
    #else:
        #embednitroerrorchannel.add_field(name="Immagine del server", value="Nessuna immagine del server disponibile.", inline=False)
        
    # Invia il messaggio di errore e attendi un po' prima di eliminarlo
    #await interaction.send("@everyone")
    #await interaction.send(embed=embednitroerrorchannel)
    #await interaction.message.delete()  # Elimina il messaggio del comando
nsfwlist = ["ass", "pussy", "boobs", "hentai", "thigh", "blowjob"]
optionsnsfwlist = ", ".join(nsfwlist)
@client.tree.command(name="nsfw", description="Generate nsfw content in a channel with appropriate permissions")
@app_commands.describe(nsfw_content=f"The nsfw content you want to see")
@app_commands.autocomplete(nsfw_content=nsfw_autocomplete)
async def gen_nsfw(interaction: discord.Interaction, nsfw_content: str):
    if interaction.channel.is_nsfw():

        if nsfw_content not in nsfwlist:
            await interaction.response.send_message(f"Option is {optionsnsfwlist}", ephemeral=True)
            return
        
        req = requests.get(f"https://nekobot.xyz/api/image?type={nsfw_content}").json()
        
        if req['message'] == "Unknown image type":
            print("Unknown image type")
            await interaction.response.send_message("Unknown image type", ephemeral=True)
            return
        
        nsfw_content = req['message']

        embednsfw = discord.Embed(title="Nsfw gen 🤤", color=discord.Color.random())
        embednsfw.add_field(name="Content", value=f"_{nsfw_content}_🥵", inline=False)
        embednsfw.add_field(name="Request by", value=f"{interaction.user.mention}", inline=False)
        embednsfw.set_image(url=nsfw_content)
        embednsfw.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embednsfw.set_thumbnail(url=ICONTBS)

        await interaction.channel.send(embed=embednsfw)
        await interaction.response.send_message("Nsfw sent!", ephemeral=True)

    else:
        embednsfwerror = discord.Embed(title="Nsfw-Error", color=discord.Color.red())
        embednsfwerror.add_field(name="Error", value="You cannot use this command in channels without nsfw permission!", inline=False)
        embednsfwerror.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embednsfwerror.set_thumbnail(url=ICONTBS)
        await interaction.response.send_message(embed=embednsfwerror, ephemeral=True)

def restart_program():
    python = sys.executable
    script_path = "tbsbot.py"
    os.execl(python, python, script_path, *sys.argv)


botdev = [1166467915378343957]

@client.command()
async def restart(ctx: commands.Context):
    await ctx.message.delete()
    if ctx.author.id in botdev:
        await ctx.send("Restarting... This may take some time", delete_after=1)
        
        await asyncio.sleep(2)
        
        restart_program()

    else:
        await ctx.send("This command can only be used by bot owner", delete_after=2)
        return

triggerlist = ["block custom words", "block suspected spam content", "block mention spam"]
optionstriggerlist = "\n".join(f"`{triggerlist}`")
@tbsstaff.command(name="automod", description="Create automod rules")
@app_commands.describe(trigger="the trigger to enable automod (block custom words, block suspected spam content, block mention spam)", name="The name of the automod rule", enable="The bool if the automod rule is enabled or disabled")
async def automodcreate(interaction: discord.Interaction, trigger: str, name: str, enable: bool):
    guild_all_tbs = interaction.guild

    if interaction.user.guild_permissions.administrator:

        if trigger not in triggerlist:
            await interaction.response.send_message(f"Option is \n{optionstriggerlist}", ephemeral=True)
            return

        # Determina l'AutoModTrigger in base all'input dell'utente
        if trigger.lower() == "block custom words":
            trigger = discord.AutoModTrigger(keyword_filter=['Set here the words you want to block'])
        elif trigger.lower() == "block suspected spam content":
            trigger = discord.AutoModTrigger(type=discord.AutoModRuleTriggerType.spam)
        elif trigger.lower() == "block mention spam":
            trigger = discord.AutoModTrigger(mention_limit=20)
        # Altre condizioni per gli altri tipi di azione...

        # Crea l'auto moderation rule nel server Discord
        rule = await guild_all_tbs.create_automod_rule(
            name=name,  # Puoi personalizzare il nome come preferisci
            event_type=discord.AutoModRuleEventType.message_send,
            trigger=trigger,
            actions=[discord.AutoModRuleAction(custom_message=None)],
            enabled=enable
        )

        if rule:
            await interaction.response.send_message("Success create automod rule, now you can configure it in your server settings", ephemeral=True)
        else:
            await interaction.response.send_message("Error while creating automod rule", ephemeral=True)
    else:
        embedautomoderror = discord.Embed(title="AutoMod rule create Error", color=discord.Color.red())
        embedautomoderror.add_field(name="Error", value="Non hai il permesso (administrator) per eseguire questo comando", inline=False)
        embedautomoderror.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embedautomoderror.set_thumbnail(url=ICONTBS)

        await interaction.response.send_message(embed=embedautomoderror, ephemeral=True)

@tickettbs.command(name="setup", description="Setup ticket")
async def ticket_setup(interaction: discord.Interaction):

    if interaction.user.guild_permissions.administrator:

        embedticketsetup = discord.Embed(title="ticket setup🎫", description="The requirements are two roles with the names of `staff` and `ticket support` and a category with the `ticket` name where all open tickets will be shown", color=discord.Color.yellow())
        embedticketsetup.add_field(name="Setup", value="Setup the ticket by clicking the button below", inline=False)
        embedticketsetup.add_field(name="Create button", value="The create button is used to create the ticket panel if all the requirements are met", inline=False)
        embedticketsetup.add_field(name="Cancel button", value="The Cancel button is used to cancel the action", inline=False)
        embedticketsetup.add_field(name="Create button", value="The auto create button is used to automatically create the necessary roles for tickets if they do not exist", inline=False)    
        embedticketsetup.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embedticketsetup.set_thumbnail(url=ICONTBS)

        await interaction.response.send_message(embed=embedticketsetup, view=TicketButtonSetup(), ephemeral=True)
    else:
        embedticketerror = discord.Embed(title="ticket-setup Error", color=discord.Color.red())
        embedticketerror.add_field(name="Error", value="Non hai il permesso (administrator) per eseguire questo comando", inline=False)
        embedticketerror.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embedticketerror.set_thumbnail(url=ICONTBS)

        await interaction.response.send_message(embed=embedticketerror, ephemeral=True)

@client.tree.context_menu(name="Translate Message")
async def trans(interaction: discord.Interaction, message: discord.Message):
    try:
        # Rileva la lingua del messaggio originale
        detected_lang = translator.detect(message.content).lang

        # Traduci il messaggio in italiano
        translated_message = translator.translate(message.content, src=detected_lang, dest='it').text

        embedtranslate = discord.Embed(title="New translate", color=discord.Color.yellow())
        embedtranslate.add_field(name="initial phrase", value=message.content, inline=True)
        embedtranslate.add_field(name="translate phrase", value=translated_message, inline=True)
        embedtranslate.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embedtranslate.set_thumbnail(url=ICONTBS)

        await interaction.response.send_message(embed=embedtranslate, ephemeral=True)

    except discord.app_commands.errors.CommandInvokeError or discord.errors.NotFound as e:
        await interaction.response.send_message(f"Errore durante la traduzione del messaggio: {str(e)}")

@client.tree.context_menu(name="See Avatar")
async def see_avatar(interaction: discord.Interaction, member: discord.Member):

    url_avatar = member.avatar.url

    embed_avatar = discord.Embed(title=f"Avatar of {member.name}", color=discord.Color.yellow())
    embed_avatar.set_thumbnail(url=ICONTBS)
    embed_avatar.set_footer(icon_url=ICONTBS, text="Powered by TBS")
    embed_avatar.set_image(url=url_avatar)

    await interaction.response.send_message(embed=embed_avatar, view=AvatarViewLink(url_avatar), ephemeral=True)

@client.tree.context_menu(name="Joined at")
async def get_joined_date(interaction: discord.Interaction, member: discord.Member):

    embed_join = discord.Embed(title=f"Date join for {member.name}", color=discord.Color.yellow())
    embed_join.set_thumbnail(url=ICONTBS)
    embed_join.set_footer(icon_url=ICONTBS, text="Powered by TBS")
    embed_join.add_field(name="Joined at", value=discord.utils.format_dt(member.joined_at))

    await interaction.response.send_message(embed=embed_join, ephemeral=True)

@client.tree.context_menu(name="Ban")
async def ban_command(interaction: discord.Interaction, member: discord.Member):
    if interaction.user.guild_permissions.administrator or interaction.user.guild_permissions.ban_members:

        await member.ban(reason="Context Command")
            
        embedban = discord.Embed(title="New Ban <:Bannicon:1165713026452816073>", color=discord.Color.yellow())
        embedban.add_field(name="Utente Bannato :bust_in_silhouette:", value=member.mention, inline=False)
        embedban.add_field(name="Bannato da <:Staff:1164636542103474296>", value=interaction.user.mention, inline=False)
        embedban.add_field(name="Motivo <:forum_badge:1163093841029628000>", value="Context Command", inline=False)
        embedban.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embedban.set_thumbnail(url=ICONTBS)
            
        await interaction.response.send_message(embed=embedban)
    else:
        embedbannoperm = discord.Embed(title="No perms <:Staff:1164636542103474296>", description="Non hai il permesso (administrator or ban_members) per eseguire questo comando", color=discord.Color.red())
        embedbannoperm.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embedbannoperm.set_thumbnail(url=ICONTBS)

        await interaction.response.send_message(embed=embedbannoperm, ephemeral=True)

@client.tree.context_menu(name="Kick")
async def kick_command(interaction: discord.Interaction, member: discord.Member):
    if interaction.user.guild_permissions.administrator or interaction.user.guild_permissions.ban_members or interaction.user.guild_permissions.kick_members:

        await member.kick(reason="Context Command")
            
        embedkick = discord.Embed(title="New Kick <:Bannicon:1165713026452816073>", color=discord.Color.yellow())
        embedkick.add_field(name="Utente Kickato :bust_in_silhouette:", value=member.mention, inline=False)
        embedkick.add_field(name="Kickato da <:Staff:1164636542103474296>", value=interaction.user.mention, inline=False)
        embedkick.add_field(name="Motivo <:forum_badge:1163093841029628000>", value="Context Command", inline=False)
        embedkick.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embedkick.set_thumbnail(url=ICONTBS)
            
        await interaction.response.send_message(embed=embedkick)
    else:
        embedbannoperm = discord.Embed(title="No perms <:Staff:1164636542103474296>", description="Non hai il permesso (administrator or ban_members or kick_members) per eseguire questo comando", color=discord.Color.red())
        embedbannoperm.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embedbannoperm.set_thumbnail(url=ICONTBS)

        await interaction.response.send_message(embed=embedbannoperm, ephemeral=True)

@client.tree.context_menu(name="Delete Message")
async def delete_message(interaction: discord.Interaction, message: discord.Message):
    if interaction.user.guild_permissions.administrator or interaction.user.guild_permissions.manage_messages:
        await message.delete()
        await interaction.response.send_message("Message deleted!", ephemeral=True)

    else:
        embedmessagenoperm = discord.Embed(title="No perms <:Staff:1164636542103474296>", description="Non hai il permesso (administrator or manage_messages) per eseguire questo comando", color=discord.Color.red())
        embedmessagenoperm.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embedmessagenoperm.set_thumbnail(url=ICONTBS)

        await interaction.response.send_message(embed=embedmessagenoperm, ephemeral=True)

@tbsstaff.command(name="set-log-channel", description="Set the log channel for member logs")
@app_commands.describe(channel="Channel where the logs will appear")
async def set_log_channel(interaction: discord.Interaction, channel: discord.TextChannel):

    if interaction.user.guild_permissions.administrator:

        server_id = str(interaction.guild.id)
        channel_log_id = str(channel.id)

        # Carica la configurazione esistente
        try:
            with open('logs_config.json', 'r', encoding='utf-8') as logs_file:
                config = json.load(logs_file)
        except (FileNotFoundError, json.decoder.JSONDecodeError):
            config = []

        # Verifica se il server ha già un canale di log impostato
        for entry in config:
            if entry["server_id"] == server_id:
                channel_mention = interaction.guild.get_channel(int(entry["channel_log_id"])).mention
                await interaction.response.send_message(f"Log channel is already set for this server. Current channel: {channel_mention}", ephemeral=True)
                return

        # Aggiungi l'entry per questo server
        config.append({"server_id": server_id, "channel_log_id": channel_log_id})

        # Scrivi il backup nel file
        with open('logs_config.json', 'w', encoding='utf-8') as logs_file:
            json.dump(config, logs_file, indent=4, ensure_ascii=False)
        
        await interaction.response.send_message(f"Log channel set to {channel.mention}", ephemeral=True)

    else:
        embedmessagenoperm = discord.Embed(title="No perms <:Staff:1164636542103474296>", description="You don't have the (administrator) permission to execute this command", color=discord.Color.red())
        embedmessagenoperm.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embedmessagenoperm.set_thumbnail(url=ICONTBS)

        await interaction.response.send_message(embed=embedmessagenoperm, ephemeral=True)

@tbsstaff.command(name="edit-log-channel", description="Edit the log channel for member logs")
@app_commands.describe(channel="Channel where the logs you want to edit will appear")
async def edit_log_channel(interaction: discord.Interaction, channel: discord.TextChannel):

    if interaction.user.guild_permissions.administrator:

        server_id = str(interaction.guild.id)
        channel_log_id = str(channel.id)

        # Carica la configurazione esistente
        try:
            with open('logs_config.json', 'r', encoding='utf-8') as logs_file:
                config = json.load(logs_file)
        except (FileNotFoundError, json.decoder.JSONDecodeError):
            config = []

        # Verifica se il server ha già un canale di log impostato
        for entry in config:
            if entry["server_id"] == server_id:
                # Modifica il canale di log esistente
                entry["channel_log_id"] = channel_log_id
                # Scrivi il backup nel file
                with open('logs_config.json', 'w', encoding='utf-8') as logs_file:
                    json.dump(config, logs_file, indent=4, ensure_ascii=False)
                await interaction.response.send_message(f"Log channel modified to {channel.mention}", ephemeral=True)
                return
            else:
                await interaction.response.send_message("You not have set the log channel yet!", ephemeral=True)

    else:
        embedmessagenoperm = discord.Embed(title="No perms <:Staff:1164636542103474296>", description="You don't have the (administrator) permission to execute this command", color=discord.Color.red())
        embedmessagenoperm.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embedmessagenoperm.set_thumbnail(url=ICONTBS)

        await interaction.response.send_message(embed=embedmessagenoperm, ephemeral=True)

@tbsstaff.command(name="delete-log-channel", description="Delete the log channel for member logs")
async def delete_log_channel(interaction: discord.Interaction):

    if interaction.user.guild_permissions.administrator:

        server_id = str(interaction.guild.id)

        # Carica la configurazione esistente
        try:
            with open('logs_config.json', 'r', encoding='utf-8') as logs_file:
                config = json.load(logs_file)
        except (FileNotFoundError, json.decoder.JSONDecodeError):
            config = []

        # Cerca il server nella configurazione
        for entry in config:
            if entry["server_id"] == server_id:
                # Rimuovi l'entry per questo server
                config.remove(entry)
                # Scrivi il backup nel file
                with open('logs_config.json', 'w', encoding='utf-8') as logs_file:
                    json.dump(config, logs_file, indent=4, ensure_ascii=False)
                await interaction.response.send_message("Log channel deleted.", ephemeral=True)
                return

        await interaction.response.send_message("You have not set the log channel yet!", ephemeral=True)

    else:
        embedmessagenoperm = discord.Embed(title="No perms <:Staff:1164636542103474296>", description="You don't have the (administrator) permission to execute this command", color=discord.Color.red())
        embedmessagenoperm.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embedmessagenoperm.set_thumbnail(url=ICONTBS)

        await interaction.response.send_message(embed=embedmessagenoperm, ephemeral=True)

@client.event
async def on_member_join(member: discord.Member):
    server_id = str(member.guild.id)

    # Carica la configurazione esistente
    try:
        with open('logs_config.json', 'r', encoding='utf-8') as logs_file:
            config = json.load(logs_file)
    except (FileNotFoundError, json.decoder.JSONDecodeError):
        config = []

    # Cerca il server nella configurazione
    for entry in config:
        if entry["server_id"] == server_id:
            channel_id = int(entry["channel_log_id"])
            log_channel = member.guild.get_channel(channel_id)

            # Invia i log nel canale appropriato
            if log_channel:
                embed = discord.Embed(
                    title="Member Joined <:join:1167890762453766288>",
                    description=f"{member.mention} join to the server!",
                    color=discord.Color.green()
                )
                embed.set_thumbnail(url=member.avatar.url)
                embed.add_field(name="Username 🏷️", value=member.name, inline=True)
                embed.add_field(name="User ID 🆔", value=member.id, inline=True)
                embed.add_field(name="Discriminator 📉", value=member.discriminator, inline=True)
                embed.add_field(name="Joined Server At 📅", value=discord.utils.format_dt(member.joined_at) if member.joined_at else "N/A", inline=True)
                embed.add_field(name="Account Created At 🗓️", value=discord.utils.format_dt(member.created_at), inline=True)
                embed.add_field(name="Bot <:shield:1170677145916428359>", value="Yes" if member.bot else "No", inline=False)
                embed.add_field(name="Nickname <:ticket:1167857574775902331>", value=member.nick, inline=True)
                embed.add_field(name="Pending Verification <:captcha:1167830817347743846>", value="Yes" if member.pending else "No", inline=True)
                embed.add_field(name="Boosted Since <a:Evolving_badge_Nitro_a_scaling:1170674725924634674>", value=member.premium_since.strftime("%Y-%m-%d %H:%M:%S") if member.premium_since else "N/A", inline=False)
                embed.add_field(name="Timed Out Until <:timeout_clock:1165739841443610654>", value=member.timed_out_until.strftime("%Y-%m-%d %H:%M:%S") if member.timed_out_until else "N/A", inline=False)
                embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")

                await log_channel.send(embed=embed, view=ModerationLogsView())
                return
            
@client.event
async def on_user_update(before, after):
    if before.avatar != after.avatar:
        try:

            try:
                with open('logs_config.json', 'r', encoding='utf-8') as logs_file:
                    config = json.load(logs_file)
            except (FileNotFoundError, json.decoder.JSONDecodeError):
                config = []

            # Invia il messaggio in ogni server in cui è presente il bot
            for guild in client.guilds:
                guild_id = str(guild.id)
                for entry in config:
                    if entry["server_id"] == guild_id:
                        channel_id = int(entry["channel_log_id"])
                        log_channel = guild.get_channel(channel_id)

                        # Invia i log nel canale appropriato
                        if log_channel:
                            embed = discord.Embed(title="Avatar Change", description=f"\n{after.mention}", color=discord.Color.yellow())
                            embed.set_author(url=after.avatar.url, name=after.name)
                            embed.set_thumbnail(url=after.avatar.url)
                            embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")

                            await log_channel.send(embed=embed)
        except Exception as e:
            print(f"Error: {str(e)}")

@client.tree.command(name='find-activity', description='Find members based on their activity')
@app_commands.describe(activity_name="Activity")
@app_commands.autocomplete(activity_name=activity_autocomplete)
async def find_activity(interaction: discord.Interaction, *, activity_name: str):
    # Ottieni tutti i membri che stanno svolgendo l'attività specificata
    members_with_activity = [
        member for member in interaction.guild.members
        if member.activities and any(activity.name.lower() == activity_name.lower() for activity in member.activities)
    ]

    if not members_with_activity:
        await interaction.response.send_message(f"No members found with the activity '{activity_name}'", ephemeral=True)
        return

    # Creazione dell'embed
    embed = discord.Embed(
        title=f"Members with the activity '{activity_name}'",
        color=discord.Color.blue()
    )
    embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")
    if activity_name == 'Spotify':
        embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/1158832924192411698/1174011413153456128/unnamed_1.png?ex=65660a54&is=65539554&hm=4c45ef2a8257bf9533e25909ad93841786f6f80719271b20e3eabd223446da60&")
    elif activity_name == 'Fortnite':
        embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/1158832924192411698/1174016104113393796/Free_Pass_-_Icon_-_Fortnite.webp?ex=65660eb3&is=655399b3&hm=e51815a6995243adb2cebfbb09715040a481e136ef36a5fb164a65f3ad8445a8&")
    elif activity_name == 'Minecraft':
        embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/1158832924192411698/1174016497409065010/download.jpeg?ex=65660f11&is=65539a11&hm=7f2e9ed1732140fe126f8c7f567aaddacaeb9703a84be9fa64f03abc97828e62&")
    elif activity_name == 'Rocket League':
        embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/1158832924192411698/1174016880223203358/640px-Rocket_League_coverart.jpg?ex=65660f6c&is=65539a6c&hm=c9c2aeb495a88c88dba608c33ebddbe7832d00bf5fe0a4c8b09b34cd53d9d8c1&")
    elif activity_name == 'Roblox':
        embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/1158832924192411698/1174017130732195900/unnamed_2.png?ex=65660fa8&is=65539aa8&hm=4195cd813ed543769213bbabd08d5b70ec46690e3b17ea60d68b6812c0f0ad7b&")
    elif activity_name == 'Grand Theft Auto V':
        embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/1158832924192411698/1174017449901948928/grand-theft-auto-v-pc-gioco-rockstar-cover.jpg?ex=65660ff4&is=65539af4&hm=e3315f5370910575ca0ee0656c7c6c4d2b06e391115d0686ae35f1779e082f73&")
    elif activity_name == 'Grand Theft Auto':
        embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/1158832924192411698/1174017449901948928/grand-theft-auto-v-pc-gioco-rockstar-cover.jpg?ex=65660ff4&is=65539af4&hm=e3315f5370910575ca0ee0656c7c6c4d2b06e391115d0686ae35f1779e082f73&")

    for member in members_with_activity:
        embed.add_field(name=f"{member.name} <a:RedCrown:1168296825070039154>", value=member.mention, inline=False)

    await interaction.response.send_message(embed=embed, ephemeral=True)

@client.tree.command(name="streaming-users", description="Show users currently streaming")
async def streaming_users(interaction: discord.Interaction):
    streaming_users = [member for member in interaction.guild.members if any(activity.type == discord.ActivityType.streaming for activity in member.activities)]

    if not streaming_users:
        await interaction.response.send_message("No one is currently streaming.", ephemeral=True)
        return

    embed = discord.Embed(title="Users Currently Streaming", color=discord.Color.blue())

    for streamer in streaming_users:
        embed.add_field(name=f"{streamer.name} <a:TwitchStreaming:1174018409537753219>", value=streamer.activities[0].name, inline=False)

    embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")

    await interaction.response.send_message(embed=embed, ephemeral=True)

@client.event
async def on_member_update(old_member, new_member):
    old_boost_status = old_member.premium_since
    new_boost_status = new_member.premium_since

    if not old_boost_status and new_boost_status:
        system_channel = new_member.guild.system_channel

        if system_channel:
            embedboost = discord.Embed(title="Boost Received", color=discord.Color.random())
            embedboost.add_field(name="", value=f"Thanks {new_member.mention}, for upgrading our server! We really appreciate your support! 🎉")
            embedboost.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            embedboost.set_thumbnail(url=ICONTBS)

            await system_channel.send(embed=embedboost)

TWITCH_API_BASE_URL = 'https://api.twitch.tv/helix'

async def get_access_token():
    data = {
        'client_id': 'ywe5rqs54fdol43u0iiv1z4r6329zq',
        'client_secret': 'yqrbdiiysekzr276g6ujbb21pi40jt',
        'grant_type': 'client_credentials'
    }

    async with aiohttp.ClientSession() as session:
        async with session.post('https://id.twitch.tv/oauth2/token', data=data) as response:
            keys = await response.json()
            return keys['access_token']

async def search_streamers(query, access_token):
    headers = {
        'Client-ID': 'ywe5rqs54fdol43u0iiv1z4r6329zq',
        'Authorization': f'Bearer {access_token}'
    }

    async with aiohttp.ClientSession() as session:
        async with session.get(f'{TWITCH_API_BASE_URL}/search/channels?query={query}&first=5', headers=headers) as response:
            data = await response.json()

            streamers = []
            for result in data['data']:
                streamers.append(result['display_name'])

            return streamers

async def activity_autocomplete_streamer(interaction: discord.Interaction, current: str) -> typing.List[app_commands.Choice[str]]:
    access_token = await get_access_token()

    if current:
        streamer_names = await search_streamers(current, access_token)
    else:
        streamer_names = []

    return [app_commands.Choice(name=name, value=name) for name in streamer_names]

async def get_user_id(streamer_name, access_token):
    headers = {
        'Client-ID': 'ywe5rqs54fdol43u0iiv1z4r6329zq',
        'Authorization': f'Bearer {access_token}'
    }

    async with aiohttp.ClientSession() as session:
        async with session.get(f'{TWITCH_API_BASE_URL}/users?login={streamer_name}', headers=headers) as response:
            data = await response.json()

            if len(data['data']) > 0:
                return data['data'][0]['id']
            else:
                return None

async def is_streamer_live(streamer_name):
    token = await get_access_token()
    headers = {
        'Client-ID': 'ywe5rqs54fdol43u0iiv1z4r6329zq',
        'Authorization': f'Bearer {token}'
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f'{TWITCH_API_BASE_URL}/streams?user_login={streamer_name}', headers=headers) as response:
                data = await response.json()

                if len(data['data']) > 0:
                    stream_data = data['data'][0]
                    title = stream_data['title']
                    streamer = stream_data['user_name']
                    game = stream_data['game_name']
                    thumbnail_url = stream_data['thumbnail_url'].replace('{width}', '640').replace('{height}', '360')
                    stream_url = f"https://www.twitch.tv/{streamer_name}"
                    viewer_count = stream_data['viewer_count']

                    return {
                        'title': title,
                        'streamer': streamer,
                        'game': game,
                        'thumbnail_url': thumbnail_url,
                        'stream_url': stream_url,
                        'viewer_count': viewer_count
                    }
                else:
                    return None
    except Exception as e:
        return "An error occurred: " + str(e)

@client.tree.command(name="live-twitch", description="See if a streamer is live")
@app_commands.describe(streamer_name="The name of the streamer you want to view")
@app_commands.autocomplete(streamer_name=activity_autocomplete_streamer)
async def twitch(interaction: discord.Interaction, streamer_name: str):
    access_token = await get_access_token()
    user_id = await get_user_id(streamer_name, access_token)

    if user_id:
        stream_info = await is_streamer_live(streamer_name)

        if stream_info:
            embed = discord.Embed(
                title=f"{streamer_name} è attualmente in diretta",
                description=f"Sta giocando a {stream_info['game']}",
                color=discord.Color.green()
            )
            embed.set_thumbnail(url=stream_info['thumbnail_url'])
            embed.add_field(name="Titolo", value=stream_info['title'], inline=False)
            embed.add_field(name="Spettatori", value=stream_info['viewer_count'], inline=True)
            embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")

            view = discord.ui.View()
            view.add_item(discord.ui.Button(label="Watch Live", url=stream_info['stream_url'], style=discord.ButtonStyle.link))

            await interaction.response.send_message(embed=embed, ephemeral=True, view=view)
        else:
            await interaction.response.send_message(f'{streamer_name} non è attualmente in diretta.', ephemeral=True)
    else:
        await interaction.response.send_message(f'{streamer_name} non esiste su Twitch.', ephemeral=True)

# ID degli utenti autorizzati
authorized_user_ids = [1166467915378343957, 1157360755264471141, 1159047698943574070, 828586013159850004, 544571452079341570]

# Funzione di verifica dell'utente autorizzato
def is_authorized(user_id):
    return user_id in authorized_user_ids

@tbsstaff.command(name="add_bad", description="Aggiungi un utente pericoloso al database")
@app_commands.describe(user_id="The id of the user you want to add to the database as dangerous", reason="The reason why add the user to the database as dangerous", severity="The level of danger: 1 (Slightly Dangerous), 2 (Dangerous), 3 (Very Dangerous)")
@app_commands.autocomplete(severity=addbad_autocomplete)
async def add_bad(interaction: discord.Interaction, user_id: str, reason: str, severity: int):

    user_id = int(user_id)

    # Verifica se l'utente che ha eseguito il comando è lo stesso dell'utente segnalato
    if interaction.user.id == user_id:
        await interaction.response.send_message("You cannot add to the database yourself as dangerous.", ephemeral=True)
        return

    if not is_authorized(interaction.user.id):
        await interaction.response.send_message("You are not authorized to run this command", ephemeral=True)
        return
    
    user = await client.fetch_user(user_id)

    try:
        # Apre la connessione e crea il cursore
        with sqlite3.connect("player_bad.db") as conn:
            db_cursor = conn.cursor()

            # Verifica che il livello di gravità sia valido
            if severity not in [1, 2, 3]:
                await interaction.response.send_message("The severity level must be 1 (Slightly Dangerous), 2 (Dangerous), or 3 (Very Dangerous).", ephemeral=True)
                return

            # Verifica se l'utente è già presente nel database
            db_cursor.execute('SELECT * FROM bad_players WHERE user_id = ?', (user_id,))
            result = db_cursor.fetchone()

            if result:
                await interaction.response.send_message(f"{user.name} is already present in the database as a dangerous user.", ephemeral=True)
            else:
                # Aggiungi l'utente al database con motivo e livello di gravità
                db_cursor.execute('INSERT INTO bad_players (user_id, reason, severity) VALUES (?, ?, ?)', (user_id, reason, severity))
                conn.commit()

                await interaction.response.send_message(f"{user.name} was successfully added to the database as a dangerous user.", ephemeral=True)

    except sqlite3.Error as e:
        print(f"Errore SQL: {e}")
        await interaction.response.send_message("An error occurred while adding dangerous user.", ephemeral=True)

    finally:
        # Chiude automaticamente il cursore alla fine del blocco with
        pass

@client.tree.command(name="check", description="Verifica se l'utente è sicuro o pericoloso")
@app_commands.describe(user="The user you want control")
async def check(interaction: discord.Interaction, user: discord.User):
    user_id = user.id

    try:
        # Apre la connessione e crea il cursore
        with sqlite3.connect("player_bad.db") as conn:
            db_cursor = conn.cursor()

            # Esegue la query
            db_cursor.execute('SELECT * FROM bad_players WHERE user_id = ?', (user_id,))
            result = db_cursor.fetchone()

            embed = discord.Embed(title="TBS SECURITY", description=f"**[TBS]({invite_url_tbs})**", color=discord.Color.green())
            embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            embed.set_thumbnail(url=ICONTBS)
            livello_emoji = {'1': '<:IdCard:1175196009484271668>', '2': '<:Mod_1:1175195850536919170>', '3': '<:Mod_2:1175195708442296330>'}
            livello_details = {'1': 'Not very dangerous', '2': 'Dangerous', '3': 'Very dangerous'}
            pericolo_details = {'1': 'This user has **multiple low severity reports** in our database, but does not pose a significant threat', '2': 'This user has **multiple dangerous reports** in our database, represents a threat, monitoring is required to avoid possible problems', '3': 'This user has **multiple very dangerous reports** in our database, represents a significant threat, constant monitoring is required and if possible **remove him from your server** as soon as possible'}

            # Gestisce il risultato
            if result:
                severity = str(result[2])  # Converte in stringa
                level_detail = livello_details.get(severity, 'sconosciuto')
                pericolo_detail = pericolo_details.get(severity, 'sconosciuto')  # Ottiene il dettaglio del livello
                description = f"**[TBS]({invite_url_tbs})**\n\n`USER:` {user.mention}\n`STATUS:` (level {severity}) {livello_emoji[severity]} - **{level_detail}**\n`REASON:` **{result[1]}**\n\n{pericolo_detail}"
                embed.description = description

                # Imposta il colore dell'embed in base al livello di gravità
                if severity == '1':
                    embed.color = discord.Color.gold()
                elif severity == '2':
                    embed.color = discord.Color.orange()
                elif severity == '3':
                    embed.color = discord.Color.red()

            else:
                embed.description = f"**[TBS]({invite_url_tbs})**\n\n`USER:` {user.mention}\n`STATUS:` **SAFE**\n\nThis user is **safe**, there are no matching reports in our database"

            await interaction.response.send_message(embed=embed)

    except sqlite3.Error as e:
        print(f"Errore SQL: {e}")
        await interaction.response.send_message("An error occurred during verification", ephemeral=True)

    finally:
        # Chiude automaticamente il cursore alla fine del blocco with
        pass

@tbsstaff.command(name="delete_user", description="Rimuovi un utente dal database")
@app_commands.describe(user_id="The id of the malicious user you want to remove from the database")
async def delete_user(interaction: discord.Interaction, user_id: str):

    user_id = int(user_id)

    if not is_authorized(interaction.user.id):
        await interaction.response.send_message("You are not authorized to run this command", ephemeral=True)
        return
    
    user = await client.fetch_user(user_id)

    try:
        # Apre la connessione e crea il cursore
        with sqlite3.connect("player_bad.db") as conn:
            db_cursor = conn.cursor()

            # Esegue la query
            db_cursor.execute('DELETE FROM bad_players WHERE user_id = ?', (user_id,))
            conn.commit()

            await interaction.response.send_message(f"The user {user.name}has been successfully removed from the database", ephemeral=True)

    except sqlite3.Error as e:
        print(f"Errore SQL: {e}")
        await interaction.response.send_message("An error occurred while removing the user from the database.", ephemeral=True)

    finally:
        # Chiude automaticamente il cursore alla fine del blocco with
        pass

@client.tree.command(name="report", description="Segnala un utente come pericoloso")
@app_commands.describe(user="The user you want to report", reason="The reason why you want to report this user", proof="Maximum one piece of evidence that represents your case, link to an image or link to a video")
async def report(interaction: discord.Interaction, user: discord.User, reason: str, proof: str = None):

    # Verifica se l'utente che ha eseguito il comando è lo stesso dell'utente segnalato
    if interaction.user.id == user.id:
        await interaction.response.send_message("You cannot self-report as dangerous.", ephemeral=True)
        return

    server_id = 1166468398184661002  # ID del server 1
    channel_id = 1180853072063377408  # ID del canale nel server 1

    # Verifica se l'utente è nel server 1
    server_1 = client.get_guild(server_id)
    channel_1 = server_1.get_channel(channel_id)

    try:
        # Apre la connessione e crea il cursore
        with sqlite3.connect("player_bad.db") as conn:
            db_cursor = conn.cursor()

            # Esegue la query
            db_cursor.execute('SELECT * FROM bad_players WHERE user_id = ?', (user.id,))
            result = db_cursor.fetchone()

            livello_emoji = {'1': '<:IdCard:1175196009484271668>', '2': '<:Mod_1:1175195850536919170>', '3': '<:Mod_2:1175195708442296330>'}
            livello_details = {'1': 'Not very dangerous', '2': 'Dangerous', '3': 'Very dangerous'}

            embed = discord.Embed(title="NEW REPORT", color=discord.Color.red())
            embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            embed.set_thumbnail(url=ICONTBS)

            if result:
                severity = str(result[2])  # Converte in stringa
                level_detail = livello_details.get(severity, 'sconosciuto')
                if proof:
                    description = f"__**[TBS]({invite_url_tbs})**__\nNew report of a dangerous user by **{interaction.user.name}**\n\n> `REPORTED NAME:` {user.name}\n> `REPORTED ID:` {user.mention} ({user.id})\n> `REASON:` **{reason}**\n> `PROOF:` {proof}\n\nThis user is already present in our database with threat (level {severity}) {livello_emoji[severity]} - **{level_detail}**"
                
                else:
                    description = f"__**[TBS]({invite_url_tbs})**__\nNew report of a dangerous user by **{interaction.user.name}**\n\n> `REPORTED NAME:` {user.name}\n> `REPORTED ID:` {user.mention} ({user.id})\n> `REASON:` **{reason}**\n\nThis user is already present in our database with threat (level {severity}) {livello_emoji[severity]} - **{level_detail}**"
                
                embed.description = description
            else:
                if proof:
                    description = f"__**[TBS]({invite_url_tbs})**__\nNew report of a dangerous user by **{interaction.user.name}**\n\n> `REPORTED NAME:` {user.name}\n> `REPORTED ID:` {user.mention} ({user.id})\n> `REASON:` **{reason}**\n> `PROOF:` {proof}\n\nThis user is not present in our database and therefore is considered **SAFE**"
                
                else:
                    description = f"__**[TBS]({invite_url_tbs})**__\nNew report of a dangerous user by **{interaction.user.name}**\n\n> `REPORTED NAME:` {user.name}\n> `REPORTED ID:` {user.mention} ({user.id})\n> `REASON:` **{reason}**\n\nThis user is not present in our database and therefore is considered **SAFE**"
                
                embed.description = description

            await channel_1.send(content="<@&1180848163729440799>", embed=embed)

            await interaction.response.send_message(f"{user.name} has been reported to our team, who will verify and, if necessary, add the user to the database of dangerous users", ephemeral=True)

    except sqlite3.Error as e:
        print(f"Errore SQL: {e}")
        await interaction.response.send_message("An error occurred during the report", ephemeral=True)

    finally:
        # Chiude automaticamente il cursore alla fine del blocco with
        pass

@tbsstaff.command(name="view_players", description="Visualizza tutti gli utenti segnalati nel database")
async def view_players(interaction: discord.Interaction):

    if not is_authorized(interaction.user.id):
        await interaction.response.send_message("You are not authorized to run this command", ephemeral=True)
        return

    try:
        # Apre la connessione e crea il cursore
        with sqlite3.connect("player_bad.db") as conn:
            db_cursor = conn.cursor()

            # Esegue la query per ottenere tutti gli utenti segnalati
            db_cursor.execute('SELECT * FROM bad_players')
            results = db_cursor.fetchall()

            livello_emoji = {'1': '<:IdCard:1175196009484271668>', '2': '<:Mod_1:1175195850536919170>', '3': '<:Mod_2:1175195708442296330>'}
            livello_details = {'1': 'Not very dangerous', '2': 'Dangerous', '3': 'Very dangerous'}

            # Creazione di una lista di embeds
            embeds = []
            current_embed = discord.Embed(title="BAD PLAYERS", color=discord.Color.red())
            current_embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            current_embed.set_thumbnail(url=ICONTBS)

            for result in results:
                user_id = result[0]

                # Ottieni l'oggetto utente Discord dal suo ID
                user = await client.fetch_user(user_id)

                if user:
                    user_name = user.name
                else:
                    user_name = f"User {user_id}"

                severity = str(result[2])  # Converte in stringa
                level_detail = livello_details.get(severity, 'sconosciuto')

                # Costruzione del campo nel formato richiesto
                field_value = f"`USER ID:` {user_id}\n`LEVEL:` (level {severity}) {livello_emoji[severity]} - **{level_detail}**\n`REASON:` {result[1]}\n\n"

                # Se il campo supera il limite, aggiungi il campo all'embed corrente
                if len(current_embed) + len(field_value) < 6000:
                    current_embed.add_field(name=f"User {user_name}", value=field_value, inline=False)
                else:
                    # Se l'embed corrente è pieno, aggiungilo alla lista e inizia uno nuovo
                    embeds.append(current_embed)
                    current_embed = discord.Embed(title="BAD PLAYERS", color=discord.Color.red())
                    current_embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")
                    current_embed.set_thumbnail(url=ICONTBS)

            # Aggiungi l'ultimo embed alla lista
            embeds.append(current_embed)

            # Invia gli embeds in sequenza
            for embed in embeds:
                await interaction.response.send_message(embed=embed)

    except sqlite3.Error as e:
        print(f"Errore SQL: {e}")
        await interaction.response.send_message("An error occurred while viewing reported users.", ephemeral=True)

    finally:
        # Chiude automaticamente il cursore alla fine del blocco with
        pass

def format_time(seconds):
    delta = datetime.timedelta(seconds=seconds)
    days = delta.days
    hours, remainder = divmod(delta.seconds, 3600)
    minutes, seconds = divmod(remainder, 60)

    formatted_time = ""
    if days > 0:
        formatted_time += f"{days} {'day' if days == 1 else 'days'} "
    if hours > 0:
        formatted_time += f"{hours} {'hour' if hours == 1 else 'hours'} "
    if minutes > 0:
        formatted_time += f"{minutes} {'minute' if minutes == 1 else 'minutes'} "
    if seconds > 0:
        formatted_time += f"{seconds} {'second' if seconds == 1 else 'seconds'}"

    return formatted_time.strip()

@client.tree.command(name="invite", description="Ottieni il link di invito del bot")
async def url_link_invite_gen(interaction: discord.Interaction):
    await interaction.response.send_message(content=f"Here is the TBS bot invitation link:\n [INVITE LINK]({invite_url_bot_tbs})", ephemeral=True)

@emojitbs.command(name="steal", description="Steal an emoji from another server")
@app_commands.describe(emoji="The id of the emoji you want to add, for example: <:Award_Icon:1163094204621262968>")
async def emojisteal(interaction: discord.Interaction, emoji: str):

    if interaction.user.guild_permissions.administrator or interaction.user.guild_permissions.manage_emojis_and_stickers or interaction.user.guild_permissions.manage_emojis:

        if emoji.startswith("<") and emoji.endswith(">"):
            id_match = re.search(r'\d{15,}', emoji)
            if id_match:
                emoji_id = id_match.group(0)
                emoji_name_match = re.search(r'(?<=:)\w+(?=:)', emoji)
                emoji_name = emoji_name_match.group(0) if emoji_name_match else "custom_emoji"

                type_url = f"https://cdn.discordapp.com/emojis/{emoji_id}.gif"

                try:
                    async with aiohttp.ClientSession() as session:
                        async with session.get(type_url) as response:
                            if response.status == 200:
                                type = "gif"
                            else:
                                type = "png"

                            img_content = await response.read()

                except aiohttp.ClientConnectionError:
                    await interaction.response.send_message("Errore durante il tentativo di recuperare l'emoji. Assicurati che l'emoji sia accessibile.", ephemeral=True)
                    return

                emoji_url = f"https://cdn.discordapp.com/emojis/{emoji_id}.{type}?quality=lossless"

                if type == "gif":
                    # Utilizza create_emoji per caricare l'immagine come allegato
                    with io.BytesIO(img_content) as img:
                        created_emoji = await interaction.guild.create_custom_emoji(name=emoji_name, image=img.read())
                        await interaction.response.send_message(f"Emoji '{created_emoji.name}' aggiunta con successo al server!", ephemeral=True)
                else:
                    type_url_png = f"https://cdn.discordapp.com/emojis/{emoji_id}.png"
                    r = requests.get(type_url_png)
                    image = Image.open(BytesIO(r.content), mode='r')
                    try:
                        image.seek(1)

                    except EOFError:
                        is_animated = False

                    else:
                        is_animated = True

                    if is_animated == True:
                        print("Error the image is animated")
                        await interaction.response.send_message("Error!", ephemeral=True)
            
                    elif is_animated == False:

                        b = BytesIO()
                        image.save(b, format='PNG')
                        b_value = b.getvalue()
                        created_emoji = await interaction.guild.create_custom_emoji(name=emoji_name, image=b_value)
                        await interaction.response.send_message(f"Emoji '{created_emoji.name}' aggiunta con successo al server!", ephemeral=True)

        else:
            await interaction.response.send_message("Error, please enter a valid emoji", ephemeral=True)

    else:
        embedmessagenoperm = discord.Embed(title="No perms <:Staff:1164636542103474296>", description="Non hai il permesso (administrator or manage_emojis_and_stickers or manage_emojis) per eseguire questo comando", color=discord.Color.red())
        embedmessagenoperm.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embedmessagenoperm.set_thumbnail(url=ICONTBS)

        await interaction.response.send_message(embed=embedmessagenoperm, ephemeral=True)

@client.tree.command(name='discord-status', description='Check the current status of Discord systems')
async def discord_status(interaction: discord.Interaction):

    # Creazione di un embed
    embed = discord.Embed(title="Discord Systems Status <a:ddevs:1177579119601516554><:server:1177579255236935700>")
    embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")
    embed.set_thumbnail(url=ICONTBS)
    embed.set_author(icon_url=interaction.user.avatar.url, name="Discord Status", url="https://discordstatus.com")

    # URL dell'API di Discord Status
    statuspage_api_url = 'https://discordstatus.com/api/v2/components.json'
    statuspage_api_url_desc = 'https://discordstatus.com/api/v2/status.json'

    try:
        # Effettua una seconda richiesta HTTP per ottenere lo stato generale
        async with httpx.AsyncClient() as client:
            response_desc = await client.get(statuspage_api_url_desc)

        # Controlla se la seconda richiesta ha avuto successo (status code 200)
        if response_desc.status_code == 200:
            data_desc = response_desc.json()
            status_description = data_desc.get('status', {}).get('description', 'N/A')

            # Aggiungi la descrizione dello stato generale come primo elemento della descrizione dell'embed
            embed.description = f"**Status**: {status_description}\n"

            # Imposta il colore dell'embed in base allo status generale
            if status_description != "All Systems Operational":
                embed.color = discord.Color.red()
            else:
                embed.color = discord.Color.green()

        else:
            await interaction.response.send_message(f"Errore nella richiesta HTTP per ottenere lo stato generale: {response_desc.status_code}", ephemeral=True)
            return
        
        # Effettua una richiesta HTTP per ottenere lo stato
        async with httpx.AsyncClient() as client:
            response = await client.get(statuspage_api_url)

        # Controlla se la richiesta ha avuto successo (status code 200)
        if response.status_code == 200:
            data = response.json()

            components = data.get('components', [])

            # Componenti da aggiungere sempre all'embed
            additional_components = ['Voice', 'Tax Calculation Service', 'Third-party', 'CloudFlare', 'Creator Payouts']

            # Ordina i componenti in base alla loro posizione
            components_sorted = sorted(components, key=lambda x: x.get('position', 0))

            # Aggiungi le informazioni dei componenti all'embed
            embed_description = ""
            for component in components_sorted:
                name = component.get('name', 'N/A')
                status = component.get('status', 'N/A')

                # Aggiungi il componente all'embed se è in quelli aggiuntivi o ha showcase True
                if name in additional_components or component.get('showcase', False):
                    emoji = '<:online_badge:1177571465210630144>' if status.lower() == 'operational' else '<:dnd_badge:1177571655355203614>'
                    embed_description += f"> {emoji} **{name}**: {status}\n"

            # Aggiungi la descrizione all'embed
            embed.description += embed_description

            # Invia l'embed nel canale del comando
            await interaction.response.send_message(embed=embed, ephemeral=True)

        else:
            await interaction.response.send_message(f"Errore nella richiesta HTTP: {response.status_code}", ephemeral=True)
    except Exception as e:
        await interaction.response.send_message(f"Si è verificato un errore: {e}", ephemeral=True)

@client.tree.command(name='discord-status-voice', description='Check the current status of Discord\'s voice systems')
async def discord_status_voice(interaction: discord.Interaction):

    # Creazione di un embed
    embed = discord.Embed(title="Status of Discord's voice systems <a:ddevs:1177579119601516554><:server:1177579255236935700>")
    embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")
    embed.set_thumbnail(url=ICONTBS)
    embed.set_author(icon_url=interaction.user.avatar.url, name="Discord Status Voice", url="https://discordstatus.com")

    # URL dell'API di Discord Status
    statuspage_api_url = 'https://discordstatus.com/api/v2/components.json'
    statuspage_api_url_desc = 'https://discordstatus.com/api/v2/status.json'

    try:
        # Effettua una seconda richiesta HTTP per ottenere lo stato generale
        async with httpx.AsyncClient() as client:
            response_desc = await client.get(statuspage_api_url_desc)

        # Controlla se la seconda richiesta ha avuto successo (status code 200)
        if response_desc.status_code == 200:
            data_desc = response_desc.json()
            status_description = data_desc.get('status', {}).get('description', 'N/A')

            # Aggiungi la descrizione dello stato generale come primo elemento della descrizione dell'embed
            embed.description = f"**Status**: {status_description}\n"

            # Imposta il colore dell'embed in base allo status generale
            if status_description != "All Systems Operational":
                embed.color = discord.Color.red()
            else:
                embed.color = discord.Color.green()

        else:
            await interaction.response.send_message(f"Errore nella richiesta HTTP per ottenere lo stato generale: {response_desc.status_code}", ephemeral=True)
            return
        # Effettua una richiesta HTTP per ottenere lo stato
        async with httpx.AsyncClient() as client:
            response = await client.get(statuspage_api_url)

        # Controlla se la richiesta ha avuto successo (status code 200)
        if response.status_code == 200:
            data = response.json()

            components = data.get('components', [])

            # Ordina i componenti in base alla loro posizione
            components_sorted = sorted(components, key=lambda x: x.get('position', 0))

            # Gruppo ID da includere nell'embed
            target_group_id = 'jk03xttfcz9b'

            # Aggiungi le informazioni dei componenti con il gruppo ID specificato all'embed
            embed_description = ""
            for component in components_sorted:
                name = component.get('name', 'N/A')
                status = component.get('status', 'N/A')
                group_id = component.get('group_id', None)

                # Aggiungi il componente all'embed solo se ha il gruppo ID desiderato
                if group_id == target_group_id:
                    # Aggiungi un'emoji prima del nome in base allo stato
                    emoji = '<:online_badge:1177571465210630144>' if status.lower() == 'operational' else '<:dnd_badge:1177571655355203614>'
                    embed_description += f"> {emoji} **{name}**: {status}\n"

            # Aggiungi la descrizione all'embed
            embed.description += embed_description

            # Invia l'embed nel canale del comando
            await interaction.response.send_message(embed=embed, ephemeral=True)

        else:
            await interaction.response.send_message(f"Errore nella richiesta HTTP: {response.status_code}", ephemeral=True)
    except Exception as e:
        await interaction.response.send_message(f"Si è verificato un errore: {e}", ephemeral=True)

@fortnitetbs.command(name="news", description="View the fortnite views")
async def news_fn(interaction: discord.Interaction):
    news = api_fn.news.fetch()
    embed = discord.Embed(title="Fortnite News <:fortnite:1178771124864167997>", description="Today's fortnite news", color=discord.Color.blurple())
    embed.set_author(name=f"{interaction.user.name}", icon_url=interaction.user.avatar.url)
    embed.add_field(name="Date <:fortniteapiold:1178771219986780170>", value=news.br.date)
    embed.set_image(url=news.br.image)
    embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")
    embed.set_thumbnail(url=ICONTBS)
    await interaction.response.send_message(embed=embed, ephemeral=True)

@fortnitetbs.command(name="map", description="View the fortnite map")
async def map_fn(interaction: discord.Interaction):
    map = api_fn.map.fetch()
    embed = discord.Embed(title="Fortnite Map <:fortnite:1178771124864167997>", description=f"[The Fortnite Map]({map.poi_image})", color=discord.Color.blurple())
    embed.set_image(url=map.poi_image)
    embed.set_author(name=f"{interaction.user.name}", icon_url=interaction.user.avatar.url)
    embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")
    embed.set_thumbnail(url=ICONTBS)
    await interaction.response.send_message(embed=embed, ephemeral=True)

@fortnitetbs.command(name="shop", description="Show the fortnite item shop")
async def shop_fn(interaction: discord.Interaction):
    fn_shop = api_fn.shop.fetch(combined=True)
    featured_entries = fn_shop.featured.entries
    if featured_entries:
        embed = discord.Embed(title="Item Shop", description="Today's fortnite shop", color=discord.Color.blurple())
        embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embed.set_author(name=f"{interaction.user.name}", icon_url=interaction.user.avatar.url)
        embed.set_thumbnail(url=ICONTBS)
        for i, entry in enumerate(featured_entries[:50], start=1):
            data_name = entry.dev_name
            data_name_v2 = data_name.split("for")[0].strip()
            data_price = entry.final_price
            item_images = entry.items[0]
            thumbnail_url = item_images.icon

            embed.add_field(
                name=f"**{data_name_v2}**",
                value=f"Price: {data_price} V-bucks\n[Preview]({thumbnail_url})",
                inline=False
            )
    await interaction.response.send_message(embed=embed, ephemeral=True)

@fortnitetbs.command(name="stats", description="View the user fortnite stats")
@app_commands.autocomplete(account_type=accounttype_autocomplete, time_window=timewindows_autocomplete)
@app_commands.describe(account_name="The name of the Fortnite account you want to view", account_type="The account type", time_window="The stats of the user you want to view, seasonal or lifetime")
async def stats_fn(interaction: discord.Interaction, account_name: str, account_type: str, time_window: str):

    embed = discord.Embed(title="Fortnite User Stats <:fortnite:1178771124864167997>")
    embed.set_author(name=f"{interaction.user.name}", icon_url=interaction.user.avatar.url)
    embed.add_field(name="Account Name <:fortniteapiold:1178771219986780170>", value=f"**`{account_name}`**")
    embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")
    embed.set_thumbnail(url=ICONTBS)

    if account_type == 'epic':
        account_type = AccountType.EPIC
        embed.add_field(name="Account Type", value="___epic___ <:epicgames:1178772283590987877>", inline=True)
    elif account_type == 'psn':
        account_type = AccountType.PSN
        embed.add_field(name="Account Type", value="___psn___ <:PS4:1178772174828490752>", inline=True)
    elif account_type == 'xbl':
        account_type = AccountType.XBL
        embed.add_field(name="Account Type", value="___xbl___ <:XBOX:1178772068540612670> / <:Switch:1178772238581899394>", inline=True)
    else:
        await interaction.response.send_message("Select the correct option, this option is invalid!", ephemeral=True)
        return

    if time_window == 'lifetime':
        time_window = TimeWindow.LIFETIME
        embed.add_field(name="Time Window <a:f_:1178771596421369976>", value="_lifetime_", inline=False)
    elif time_window == 'season':
        time_window = TimeWindow.SEASON
        embed.add_field(name="Time Window <a:f_:1178771596421369976>", value="_season_", inline=False)
    else:
        await interaction.response.send_message("Select the correct option, this option is invalid!", ephemeral=True)
        return
    
    try:
        # Usa Image.all come valore per il parametro image
        stats = api_fn.stats.fetch_by_name(name=account_name, account_type=account_type, time_window=time_window, image=StatsImageType.ALL)

    except Exception as e:
        await interaction.response.send_message(f"Error:\n _`{e}`_", ephemeral=True)
        return
    
    embed.set_image(url=stats.image_url)
    embed.add_field(name="Battle Pass <:battlepass:1178771323959377931>", value=f"`LEVEL:` **___{stats.battle_pass.level}___**\n`PROGRESS:` **___{stats.battle_pass.progress}%___**", inline=True)

    await interaction.response.send_message(embed=embed, ephemeral=True)

@client.tree.command(name="spotify-track", description="Track Spotify")
async def track(interaction: discord.Interaction, user: discord.Member = None):
    user = user or interaction.user
    spotify_result = next((activity for activity in user.activities if isinstance(activity, discord.Spotify)), None)

    if spotify_result is None or not isinstance(spotify_result, discord.Spotify) or not hasattr(spotify_result, 'album_cover_url'):
        await interaction.response.send_message(f'{user.name} is not listening to Spotify or the activity does not have an album cover', ephemeral=True)
        return

    # Verifica che l'attività Spotify abbia l'URL dell'immagine dell'album
    album_cover_url = spotify_result.album_cover_url
    if not album_cover_url:
        await interaction.response.send_message(f'{user.name} is not listening to Spotify or the activity does not have an album cover', ephemeral=True)
        return

    album_image = Image.open(requests.get(album_cover_url, stream=True).raw).convert('RGBA')



    # Images
    track_background_image = Image.open('spotify_template.png')
    album_image = Image.open(requests.get(spotify_result.album_cover_url, stream=True).raw).convert('RGBA')

    # Fonts
    title_font = ImageFont.truetype('theboldfont.ttf', 16)
    artist_font = ImageFont.truetype('theboldfont.ttf', 14)
    album_font = ImageFont.truetype('theboldfont.ttf', 14)
    start_duration_font = ImageFont.truetype('theboldfont.ttf', 12)
    end_duration_font = ImageFont.truetype('theboldfont.ttf', 12)

    # Positions
    title_text_position = 150, 30
    artist_text_position = 150, 60
    album_text_position = 150, 80
    start_duration_text_position = 150, 122
    end_duration_text_position = 515, 122

    # Draws
    draw_on_image = ImageDraw.Draw(track_background_image)
    draw_on_image.text(title_text_position, spotify_result.title, 'white', font=title_font)
    draw_on_image.text(artist_text_position, f'by {spotify_result.artist}', 'white', font=artist_font)
    draw_on_image.text(album_text_position, spotify_result.album, 'white', font=album_font)
    draw_on_image.text(start_duration_text_position, '0:00', 'white', font=start_duration_font)
    draw_on_image.text(end_duration_text_position,
                       f"{dateutil.parser.parse(str(spotify_result.duration)).strftime('%M:%S')}",
                       'white', font=end_duration_font)

    # Background colour
    album_color = album_image.getpixel((250, 100))
    background_image_color = Image.new('RGBA', track_background_image.size, album_color)
    background_image_color.paste(track_background_image, (0, 0), track_background_image)

    # Resize
    album_image_resize = album_image.resize((140, 160))
    background_image_color.paste(album_image_resize, (0, 0), album_image_resize)

    # Save image
    background_image_color.convert('RGB').save('spotify.jpg', 'JPEG')

    await interaction.response.send_message(file=discord.File('spotify.jpg'), ephemeral=True)

# Definisci il comando /purge-ticket
@tickettbs.command(name='purge', description='Delete all tickets in the server')
async def purge_ticket(interaction: discord.Interaction):

    if interaction.user.guild_permissions.administrator:
    
        # Controlla tutti i canali del server
        for channel in interaction.guild.channels:
            # Verifica se il canale è testuale e ha il topic "Ticket open by"
            if isinstance(channel, discord.TextChannel) and channel.topic and 'Ticket open by' in channel.topic:
                try:
                    # Elimina il canale
                    await channel.delete()
                except discord.Forbidden:
                    # Gestisci il caso in cui il bot non abbia i permessi per eliminare il canale
                    print(f"Insufficient permissions to delete channel {channel.name}.")
                except discord.HTTPException as e:
                    # Gestisci altri errori durante l'eliminazione del canale
                    print(f"Error deleting channel {channel.name}: {e}")

        await interaction.response.send_message("Ticket channels purged successfully", ephemeral=True)
    else:
        embedmessagenoperm = discord.Embed(title="No perms <:Staff:1164636542103474296>", description="You don't have the (administrator) permission to execute this command", color=discord.Color.red())
        embedmessagenoperm.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embedmessagenoperm.set_thumbnail(url=ICONTBS)

        await interaction.response.send_message(embed=embedmessagenoperm, ephemeral=True)

@tickettbs.command(name='add', description='Add a member or role to a ticket')
async def add_ticket(interaction: discord.Interaction, target: typing.Union[discord.Member, discord.Role], channel: discord.TextChannel):
    # Verifica se il membro ha i permessi di amministratore
    if interaction.user.guild_permissions.administrator:
        # Verifica se il canale è testuale e ha il topic "Ticket open by"
        if channel.topic and 'Ticket open by' in channel.topic:
            try:
                # Aggiungi il membro o ruolo al canale
                await channel.set_permissions(target, send_messages=True, read_message_history=True, view_channel=True)
                await interaction.response.send_message(f"{target.mention} has been added to {channel.mention}", ephemeral=True)
            except discord.Forbidden:
                # Gestisci il caso in cui il bot non abbia i permessi per aggiungere il membro o il ruolo al canale
                await interaction.response.send_message(f"Insufficient permissions to add {target.mention} to {channel.mention}", ephemeral=True)
            except discord.HTTPException as e:
                # Gestisci altri errori durante l'aggiunta del membro o del ruolo al canale
                await interaction.response.send_message(f"Error adding {target.mention} to {channel.mention}: {e}", ephemeral=True)
        else:
            await interaction.response.send_message(f"{channel.mention} is not a ticket", ephemeral=True)
    else:
        embedmessagenoperm = discord.Embed(title="No perms <:Staff:1164636542103474296>", description="You don't have the (administrator) permission to execute this command", color=discord.Color.red())
        embedmessagenoperm.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embedmessagenoperm.set_thumbnail(url=ICONTBS)

        await interaction.response.send_message(embed=embedmessagenoperm, ephemeral=True)

@client.tree.command(name='qrcode', description='Generate a QR code for the provided link')
@app_commands.describe(url="The URL of the site for which you want to generate a QR code")
async def generate_qrcode(interaction: discord.Interaction, url: str):
    try:
        # Verifica se l'URL è valido
        if not validators.url(url):
            raise ValueError("Invalid URL")
        
        # Creare l'oggetto QRCode
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.ERROR_CORRECT_L,
            box_size=10,
            border=0,
        )
        
        # Aggiungere i dati al QRCode
        qr.add_data(url)
        qr.make(fit=True)
        
        # Creare l'immagine QRCode usando PIL
        img = qr.make_image(fill_color="black", back_color="white")
        
        # Salvare l'immagine QRCode in un buffer
        img_buffer = io.BytesIO()
        img.save(img_buffer, format="PNG")
        img_buffer.seek(0)
        
        # Invia l'immagine QRCode nell'interazione
        await interaction.response.send_message(
            file=discord.File(img_buffer, filename="qrcode.png"),
            ephemeral=True
        )
    except Exception as e:
        # Gestisci gli errori durante la generazione del QR code
        await interaction.response.send_message(f"Error generating QR code: {e}", ephemeral=True)

@client.tree.command(name='qrcode-gen', description='Generate a QR code via the entered prompt')
@app_commands.describe(prompt="The description of the QR code that will be generated")
async def generate_qr_code(interaction: discord.Interaction, prompt: str):
    try:
        # Crea il QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.ERROR_CORRECT_L,
            box_size=10,
            border=0,
        )
        qr.add_data(prompt)
        qr.make(fit=True)

        img = qr.make_image(fill_color="black", back_color="white")

        # Salvare l'immagine QRCode in un buffer
        img_buffer = io.BytesIO()
        img.save(img_buffer, format="PNG")
        img_buffer.seek(0)
        
        # Invia l'immagine QRCode nell'interazione
        await interaction.response.send_message(
            file=discord.File(img_buffer, filename="qrcodegen.png"),
            ephemeral=False
        )
    except Exception as e:
        # Gestisci gli errori durante la generazione del QR code
        await interaction.response.send_message(f"Error generating QR code: {e}", ephemeral=True)

@client.tree.command(name='ascii', description='Generate ASCII art from a prompt')
@app_commands.describe(prompt="The text you want to convert to ASCII art")
async def generate_ascii(interaction: discord.Interaction, prompt: str):
    try:
        # Crea un oggetto Figlet per generare l'ASCII art
        figlet = Figlet()

        # Genera l'ASCII art dal prompt
        ascii_art = figlet.renderText(prompt)

        # Invia l'ASCII art nell'interazione
        await interaction.response.send_message(f"```\n{ascii_art}\n```", ephemeral=True)
    except Exception as e:
        # Gestisci gli errori durante la generazione dell'ASCII art
        await interaction.response.send_message(f"Error generating ASCII art: {e}", ephemeral=True)

@tbsstaff.command(name='nuke', description='Delete and clone channels')
@app_commands.describe(channel="The channel you want nuke text/voice")
async def nuke(interaction: discord.Interaction, channel: typing.Union[discord.TextChannel, discord.VoiceChannel] = None):
    # Verifica se l'utente ha il permesso di amministratore
    if interaction.user.guild_permissions.administrator:
        # Ottieni il canale in cui è stato eseguito il comando
        original_channel = channel or interaction.channel
        guild = interaction.guild

        new_channel = await original_channel.clone(reason=f"Nuked by {interaction.user.name}")

        # Invia un messaggio nel nuovo canale
        await new_channel.send(f'Channel nuked by {interaction.user.name}')

        # Elimina il canale originale
        await original_channel.delete()

        await interaction.response.send_message('Channel nuked succesfully!', ephemeral=True)
    else:
        embedmessagenoperm = discord.Embed(title="No perms <:Staff:1164636542103474296>", description="You don't have the (administrator) permission to execute this command", color=discord.Color.red())
        embedmessagenoperm.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embedmessagenoperm.set_thumbnail(url=ICONTBS)

        await interaction.response.send_message(embed=embedmessagenoperm, ephemeral=True)

@client.tree.command(name='status', description='Check the current status of Tbs Systems')
async def tbs_status(interaction: discord.Interaction):

    # Creazione di un embed
    embed = discord.Embed(title="Tbs Systems Status <a:tbsemoji:1178356240598962176><:server:1177579255236935700>")
    embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")
    embed.set_thumbnail(url=ICONTBS)
    embed.set_author(icon_url=interaction.user.avatar.url, name="Tbs Status", url="https://tbsbot.statuspage.io")

    # URL dell'API di Discord Status
    statuspage_api_url = 'https://rc8kzb86c66n.statuspage.io/api/v2/components.json'
    statuspage_api_url_desc = 'https://rc8kzb86c66n.statuspage.io/api/v2/status.json'

    try:
        # Effettua una seconda richiesta HTTP per ottenere lo stato generale
        async with httpx.AsyncClient() as client:
            response_desc = await client.get(statuspage_api_url_desc)

        # Controlla se la seconda richiesta ha avuto successo (status code 200)
        if response_desc.status_code == 200:
            data_desc = response_desc.json()
            status_description = data_desc.get('status', {}).get('description', 'N/A')

            # Aggiungi la descrizione dello stato generale come primo elemento della descrizione dell'embed
            embed.description = f"**Status**: {status_description}\n"

            # Imposta il colore dell'embed in base allo status generale
            if status_description != "All Systems Operational":
                embed.color = discord.Color.red()
            else:
                embed.color = discord.Color.green()

        else:
            await interaction.response.send_message(f"Errore nella richiesta HTTP per ottenere lo stato generale: {response_desc.status_code}", ephemeral=True)
            return
        
        # Effettua una richiesta HTTP per ottenere lo stato
        async with httpx.AsyncClient() as client:
            response = await client.get(statuspage_api_url)

        # Controlla se la richiesta ha avuto successo (status code 200)
        if response.status_code == 200:
            data = response.json()

            components = data.get('components', [])

            # Ordina i componenti in base alla loro posizione
            components_sorted = sorted(components, key=lambda x: x.get('position', 0))

            # Aggiungi le informazioni dei componenti ordinati all'embed
            embed_description = ""
            for component in components_sorted:
                name = component.get('name', 'N/A')
                status = component.get('status', 'N/A')

                # Aggiungi il componente all'embed se è in quelli aggiuntivi o ha showcase True
                if component.get('showcase', False):
                    emoji = '<:online_badge:1177571465210630144>' if status.lower() == 'operational' else '<:dnd_badge:1177571655355203614>'
                    embed_description += f"> {emoji} **{name}**: {status}\n"

            # Aggiungi la descrizione all'embed
            embed.description += embed_description

            # Invia l'embed nel canale del comando
            await interaction.response.send_message(embed=embed, ephemeral=True)

        else:
            await interaction.response.send_message(f"Errore nella richiesta HTTP: {response.status_code}", ephemeral=True)
    except Exception as e:
        await interaction.response.send_message(f"Si è verificato un errore: {e}", ephemeral=True)

@client.tree.command(name='topgg-bot', description='Get statistics of a bot on Top.gg')
@app_commands.describe(bot_id="The ID of the bot whose statistics you want to search for")
async def topgg_info(interaction: discord.Interaction, bot_id: str):
    # Token di Top.gg del tuo bot
    topgg_token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjExNjY0NjkyMjc1NjIxNjAyMTgiLCJib3QiOnRydWUsImlhdCI6MTcwMTI5MTI0NH0.62GuaAHiluDJROI9sEKH0PfIbntDqr9zLjv0fe91t9Y'

    # URL dell'API di Top.gg
    topgg_api_url = f'https://top.gg/api/bots/{bot_id}'

    try:
        # Effettua una richiesta HTTP per ottenere le statistiche del bot su Top.gg
        async with httpx.AsyncClient() as client:
            headers = {'Authorization': topgg_token}
            response = await client.get(topgg_api_url, headers=headers)

        # Controlla se la richiesta ha avuto successo (status code 200)
        if response.status_code == 200:
            data = response.json()

            # Estrai le informazioni desiderate dai dati ricevuti
            bot_name = data.get('username', 'N/A')
            votes = data.get('points', 'N/A')
            guilds_count = len(data.get('guilds', []))
            monthly_votes = data.get('monthlyPoints', 'N/A')
            prefix = data.get('prefix', 'N/A')
            invite_link = data.get('invite', 'N/A')
            support_server = f'https://discord.gg/{data.get("support")}'
            owners = ', '.join(data.get('owners', []))
            tags = ', '.join(data.get('tags', []))

            # Creazione di un embed con tutte le informazioni
            embed = discord.Embed(title=f'Top.gg Statistics for {bot_name} <:topggwhite:1180507309361868992><:topgg_ico_chart:1180507410146787348>', color=discord.Color.yellow())
            embed.set_thumbnail(url=ICONTBS)
            embed.set_author(name=bot_name, url=invite_link, icon_url=interaction.user.avatar.url)
            embed.add_field(name='Total Votes <:topgg_ico_chart:1180507410146787348>', value=votes, inline=True)
            embed.add_field(name='Guilds <:Community_Server_Boost_public:1180507839257641031>', value=guilds_count, inline=True)
            embed.add_field(name='Monthly Votes <:topgg_ico_event:1180508018308300842>', value=monthly_votes, inline=True)
            embed.add_field(name='Prefix <:premium:1180508590264565770>', value=prefix, inline=True)
            embed.add_field(name='Owners <a:SKY_whitecrown:1180508992309571616>', value=f"<@{owners}>", inline=False)
            embed.add_field(name='Tags <:SKY_TAG:1180509162610892960>', value=tags, inline=False)

            viewtopgg = discord.ui.View()
            viewtopgg.add_item(discord.ui.Button(label="Invite Bot", emoji="<:Invite:1178413450611925042>", url=invite_link))
            viewtopgg.add_item(discord.ui.Button(label="Support Server", emoji="<:ddevs_winter:1180183946747719700>", url=support_server))

            # Invia l'embed nel canale
            await interaction.response.send_message(embed=embed, view=viewtopgg, ephemeral=True)

        else:
            await interaction.response.send_message(f"Error fetching Top.gg stats. Status code: {response.status_code}", ephemeral=True)

    except Exception as e:
        await interaction.response.send_message(f"An error occurred: {e}", ephemeral=True)

# Comando per impostare il messaggio di benvenuto
@welcometbs.command(name='set', description='Set welcome message for the server')
@app_commands.describe(channel="The channel in which the welcome message will be sent", title="The title of the welcome message", message="The welcome message")
async def set_welcome(interaction: discord.Interaction, channel: discord.TextChannel, title: str, message: str):
        
    if interaction.user.guild_permissions.administrator:

        # Creazione di un dizionario con le informazioni del messaggio di benvenuto
        welcome_data = {
            'channel_id': channel.id,
            'title': title,
            'message': message
        }

        # Carica i dati esistenti dal file JSON
        try:
            with open('welcome_servers.json', 'r') as file:
                servers_data = json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            # Se il file non esiste, crea un nuovo dizionario vuoto
            servers_data = {}

        # Aggiorna i dati con le nuove informazioni del server
        server_id = str(interaction.guild.id)
        servers_data[server_id] = welcome_data

        # Scrivi i dati aggiornati nel file JSON
        with open('welcome_servers.json', 'w') as file:
            json.dump(servers_data, file, indent=4)

        await interaction.response.send_message(f'Welcome message set for {interaction.guild.name}!', ephemeral=True)

    else:
        embedmessagenoperm = discord.Embed(title="No perms <:Staff:1164636542103474296>", description="You don't have the (administrator) permission to execute this command", color=discord.Color.red())
        embedmessagenoperm.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embedmessagenoperm.set_thumbnail(url=ICONTBS)

        await interaction.response.send_message(embed=embedmessagenoperm, ephemeral=True)

# Funzione ausiliaria per ottenere i dati di benvenuto di un server
def get_welcome_data(server_id: str) -> dict:
    try:
        with open('welcome_servers.json', 'r') as file:
            servers_data = json.load(file)
            return servers_data.get(server_id, {})
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


# Comando per modificare il messaggio di benvenuto
@welcometbs.command(name='edit', description='Edit welcome message for the server')
@app_commands.describe(title="The title of the welcome message you want to edit", message="The welcome message you want to edit")
async def edit_welcome(interaction: discord.Interaction, title: str, message: str):
        
    if interaction.user.guild_permissions.administrator:

        server_id = str(interaction.guild.id)
        welcome_data = get_welcome_data(server_id)

        if welcome_data:
            welcome_data['title'] = title
            welcome_data['message'] = message

            # Aggiorna i dati nel file JSON
            try:
                with open('welcome_servers.json', 'r') as file:
                    servers_data = json.load(file)
            except (FileNotFoundError, json.JSONDecodeError):
                servers_data = {}

            servers_data[server_id] = welcome_data

            with open('welcome_servers.json', 'w') as file:
                json.dump(servers_data, file, indent=4)

            await interaction.response.send_message(f'Welcome message updated for {interaction.guild.name}!', ephemeral=True)
        else:
            await interaction.response.send_message(f'Welcome message not set for {interaction.guild.name}. Use `/welcome set` first.', ephemeral=True)

    else:
        embedmessagenoperm = discord.Embed(title="No perms <:Staff:1164636542103474296>", description="You don't have the (administrator) permission to execute this command", color=discord.Color.red())
        embedmessagenoperm.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embedmessagenoperm.set_thumbnail(url=ICONTBS)

        await interaction.response.send_message(embed=embedmessagenoperm, ephemeral=True)

# Comando per eliminare il messaggio di benvenuto
@welcometbs.command(name='delete', description='Delete welcome message for the server')
async def delete_welcome(interaction: discord.Interaction):
        
    if interaction.user.guild_permissions.administrator:    

        server_id = str(interaction.guild.id)
        welcome_data = get_welcome_data(server_id)

        if welcome_data:
            # Elimina i dati di benvenuto per il server
            try:
                with open('welcome_servers.json', 'r') as file:
                    servers_data = json.load(file)
            except (FileNotFoundError, json.JSONDecodeError):
                servers_data = {}

            servers_data.pop(server_id, None)

            with open('welcome_servers.json', 'w') as file:
                json.dump(servers_data, file, indent=4)

            await interaction.response.send_message(f'Welcome message deleted for {interaction.guild.name}!', ephemeral=True)
        else:
            await interaction.response.send_message(f'Welcome message not set for {interaction.guild.name}. Use `/welcome set` first.', ephemeral=True)

    else:
        embedmessagenoperm = discord.Embed(title="No perms <:Staff:1164636542103474296>", description="You don't have the (administrator) permission to execute this command", color=discord.Color.red())
        embedmessagenoperm.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embedmessagenoperm.set_thumbnail(url=ICONTBS)

        await interaction.response.send_message(embed=embedmessagenoperm, ephemeral=True)

# Evento chiamato quando un utente entra in un server
@client.event
async def on_member_join(member: discord.Member):
    # Carica i dati dal file JSON
    try:
        with open('welcome_servers.json', 'r') as file:
            servers_data = json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        # Se il file non esiste, non fare nulla
        return

    # Ottieni l'ID del server
    server_id = str(member.guild.id)

    # Verifica se il server ha un messaggio di benvenuto impostato
    if server_id in servers_data:
        welcome_data = servers_data[server_id]
        channel_id = welcome_data['channel_id']
        title = welcome_data['title']
        message = welcome_data['message']

        # Ottieni il canale di benvenuto
        welcome_channel = member.guild.get_channel(channel_id)

        if welcome_channel:
            # Creazione di un embed di benvenuto
            embed = discord.Embed(title=title, description=message, color=discord.Color.green())
            if member.guild.icon.url:
                embed.set_thumbnail(url=member.guild.icon.url)
            embed.set_author(name=member.name, icon_url=member.avatar.url)

            # Invia l'embed nel canale di benvenuto
            await welcome_channel.send(content=member.mention, embed=embed)

@tbsrole.command(name='info', description='Get information about a role')
@app_commands.describe(role="The role you want to see information about")
async def role_info(interaction: discord.Interaction, role: discord.Role):
    # Creazione di un embed con le informazioni sul ruolo
    embed = discord.Embed(title=f'Role Information: {role.name}', color=role.color)
    embed.add_field(name='ID', value=role.id, inline=False)
    embed.add_field(name='Color', value=str(role.color), inline=False)
    embed.add_field(name='Created At', value=role.created_at.strftime('%Y-%m-%d %H:%M:%S'), inline=False)
    embed.add_field(name='Position', value=role.position, inline=False)
    embed.add_field(name='Mentionable', value=role.mentionable, inline=False)
    embed.add_field(name='Hoisted', value=role.hoist, inline=False)
    embed.add_field(name='Members', value=len(role.members), inline=False)

    # Invia l'embed nel canale
    await interaction.response.send_message(embed=embed, ephemeral=True)

@client.tree.command(name='ig-details', description='Get instagram account information')
@app_commands.describe(username="The username of the Instagram account for which you want to see information")
async def insta_det(interaction: discord.Interaction, username: str):
        
    try:

        profile = instaloader.Profile.from_username(insta.context, username)

        embed = discord.Embed(title="Instagram account details", description=f"Description of {username} instagram account", color=discord.Color.random())
        if profile.biography:
            embed.add_field(name="Biography", value=profile.biography, inline=False)
        else:
            embed.add_field(name="Biography", value="N/A", inline=False)

        embed.add_field(name="Followers", value=profile.followers, inline=True)
        embed.add_field(name="Following", value=profile.followees, inline=True)
        embed.add_field(name="Private Account", value=profile.is_private, inline=True)
        embed.add_field(name="Verified Account", value=profile.is_verified, inline=True)
        embed.add_field(name="Business Account", value=profile.is_business_account, inline=True)
        if profile.is_business_account:
            embed.add_field(name="Business Category Name", value=profile.business_category_name, inline=False)
        embed.add_field(name="UserId Account", value=profile.userid, inline=True)
        embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embed.set_author(name=f"{interaction.user.name}", icon_url=interaction.user.avatar.url)
        embed.set_thumbnail(url=profile.get_profile_pic_url())
        embed.add_field(name="link", value=profile.external_url)

        await interaction.response.send_message(embed=embed, ephemeral=True)
    
    except Exception as e:
        await interaction.response.send_message(f"Error: {e}", ephemeral=True)

@client.tree.command(name='spoiler', description='Send a file with spoiler')
async def spoiler_file(interaction: discord.Interaction, file: discord.Attachment, channel: discord.TextChannel = None):

    channel = channel or interaction.channel

    # Ottieni il contenuto binario del file
    file_content = await file.read()

    # Invia il file come spoiler
    await channel.send(file=discord.File(io.BytesIO(file_content), filename=file.filename, spoiler=True))

    await interaction.response.send_message("File inviato come spoiler!", ephemeral=True)

# Comando per aggiungere un id al file JSON
@client.tree.command(name='add-authorized-id', description='Add user id')
async def add_authorized_id(interaction: discord.Interaction, user: discord.User):

    if interaction.user.id not in botdev:
        await interaction.response.send_message("Non sei autorizzato a utilizzare questo comando.", ephemeral=True)
        return

    authorized_ids = load_authorized_ids()

    # Verifica se l'id è già presente
    if user.id in authorized_ids:
        await interaction.response.send_message("L'utente è già autorizzato.", ephemeral=True)
    else:
        authorized_ids.append(user.id)
        save_authorized_ids(authorized_ids)
        await interaction.response.send_message(f"L'utente {user.mention} è stato aggiunto come autorizzato.", ephemeral=True)

# Comando per rimuovere un id dal file JSON
@client.tree.command(name='remove-authorized-id', description='Remove a user id')
async def remove_authorized_id(interaction: discord.Interaction, user: discord.User):

    if interaction.user.id not in botdev:
        await interaction.response.send_message("Non sei autorizzato a utilizzare questo comando.", ephemeral=True)
        return
    
    authorized_ids = load_authorized_ids()

    # Verifica se l'id è presente
    if user.id in authorized_ids:
        authorized_ids.remove(user.id)
        save_authorized_ids(authorized_ids)
        await interaction.response.send_message(f"L'utente {user.mention} è stato rimosso come autorizzato.", ephemeral=True)
    else:
        await interaction.response.send_message("L'utente non è presente tra gli autorizzati.", ephemeral=True)

@client.tree.command(name="chat-gpt", description="Chiedi a qualcosa a chatgpt!")
@app_commands.describe(prompt="what you want to ask or say to chatgpt")
async def gpt_test(interaction: discord.Interaction, prompt: str):

    # Controlla se l'utente è autorizzato
    authorized_ids = load_authorized_ids()
    if interaction.user.id not in authorized_ids:
        await interaction.response.send_message("Non sei autorizzato a utilizzare questo comando.", ephemeral=True)
        return

    try:
        response = openai.Completion.create(
            model="text-davinci-003",
            prompt=prompt,
            max_tokens=200,
            temperature=0.9
        )
        
        if "choices" in response:
            text = response["choices"][0]["text"]
            embed = discord.Embed(title="AI response <a:tbsemoji:1178356240598962176>", description=text, color=discord.Color.random())
            embed.set_thumbnail(url=ICONTBS)
            embed.set_footer(icon_url=ICONTBS, text="Powered by TBS")
            await interaction.response.send_message(content=f"> {prompt}", embed=embed)
        else:
            await interaction.response.send_message("La risposta dall'API di OpenAI non contiene la chiave 'choices'", ephemeral=True)
    except Exception as e:
        await interaction.response.send_message(f"Si è verificato un errore durante la richiesta all'API di OpenAI: {str(e)}", ephemeral=True)

@client.tree.command(name='cat', description='generate a random cat image')
async def cat(interaction: discord.Interaction):
    response = requests.get('https://api.thecatapi.com/v1/images/search')
    data = response.json()

    if data and isinstance(data, list) and len(data) > 0:
        image_cat = data[0]['url']

        embed_cat = discord.Embed(description="**Meow** <a:catdance:1189343158513963090>", color=discord.Color.yellow())
        embed_cat.set_image(url=image_cat)
        embed_cat.set_footer(icon_url=ICONTBS, text="Powered by TBS")
        embed_cat.set_thumbnail(url=ICONTBS)

        await interaction.response.send_message(embed=embed_cat, ephemeral=True)
    else:
        await interaction.response.send_message("Errore nel recupero dell'immagine del gatto", ephemeral=True)

@client.tree.command(name='calculate', description='Perform a mathematical calculation')
@app_commands.describe(expression="the calculation from which to draw the result (valid operators only: + - * /)")
async def calculate_math(interaction: discord.Interaction, expression: str):
    try:
        result = eval(expression)

        await interaction.response.send_message(f'Result of `{expression}` is `{result}`', ephemeral=True)
    except Exception as e:
        await interaction.response.send_message(f'Error in evaluating the expression: {str(e)}', ephemeral=True)

@client.tree.command(name='randomgif', description='Get a random GIF')
@app_commands.describe(category="A category of the meme you want see, for example rocket-league")
async def random_gif(interaction: discord.Interaction, category: str):
    response = requests.get(f'https://api.giphy.com/v1/gifs/random?api_key=EIyHtScalcI2tpj7EVSulEmQIUUDRhFC&tag={category}&rating=g')
    data = response.json()

    if 'data' in data and 'url' in data['data']:
        gif_url = data['data']['url']

        await interaction.response.send_message(content=gif_url, ephemeral=True)
    else:
        await interaction.response.send_message("Impossibile recuperare la GIF.", ephemeral=True)

#@tbs.command(name='afk', description='Set AFK status with an optional reason')
#@app_commands.describe(reason="The reason why you go afk")
#async def afk_command(interaction: discord.Interaction, reason: str = None):
#    user_id = str(interaction.user.id)

#    # Carica la configurazione esistente
#    try:
#        with open('afk_config.json', 'r', encoding='utf-8') as afk_file:
#            afk_data = json.load(afk_file)
#    except (FileNotFoundError, json.decoder.JSONDecodeError):
#        afk_data = {}

#    # Imposta l'utente come AFK
#    afk_data[user_id] = {"server_id": str(interaction.guild.id), "channel_id": str(interaction.channel.id), "start_time": datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"), "reason": reason}

#    # Scrivi il backup nel file
#    with open('afk_config.json', 'w', encoding='utf-8') as afk_file:
#        json.dump(afk_data, afk_file, indent=4, ensure_ascii=False)
#
#    await interaction.response.send_message(f'You are now AFK. Reason: {reason}' if reason else 'You are now AFK.')

#@client.event
#async def on_presence_update(before, after):
#    user_id = str(after.id)
#
#    # Carica la configurazione esistente
#    try:
#        with open('afk_config.json', 'r', encoding='utf-8') as afk_file:
#            afk_data = json.load(afk_file)
#    except (FileNotFoundError, json.decoder.JSONDecodeError):
#        afk_data = {}
#
#    member = after.guild.get_member(after.id)
#    if after.status != before.status:
#        # L'utente ha cambiato stato
#        if after.status != discord.Status.offline:
#            if user_id in afk_data:
#                # L'utente era AFK
#                server_id = afk_data[user_id]["server_id"]
#                channel_id = afk_data[user_id]["channel_id"]
#                start_time = datetime.datetime.strptime(afk_data[user_id]["start_time"], "%Y-%m-%d %H:%M:%S")
#                elapsed_time_seconds = (datetime.datetime.utcnow() - start_time).total_seconds()
#                formatted_elapsed_time = format_time(elapsed_time_seconds)
#                del afk_data[user_id]  # Rimuovi l'utente dalla lista AFK
#
#                # Scrivi il backup nel file
#                with open('afk_config.json', 'w', encoding='utf-8') as afk_file:
#                    json.dump(afk_data, afk_file, indent=4, ensure_ascii=False)
#
#                # Invia un messaggio di bentornato nel server corretto
#                guild = client.get_guild(int(server_id))
#                channel = client.get_channel(int(channel_id))
#                if guild and channel:
#                    await channel.send(f'Welcome back! {member.mention} was AFK for {formatted_elapsed_time}.')

client.run(Token)